#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class LostintravelsdkApollo_apiCompiledField, LostintravelsdkApollo_apiCustomScalarAdapters, LostintravelsdkCreateUser, LostintravelsdkCreateNewUserMutationCompanion, LostintravelsdkCreateNewUserMutation, LostintravelsdkCreateNewUserMutationLocation, LostintravelsdkCreateNewUserMutationCreateNewUser, LostintravelsdkCreateNewUserMutationData, LostintravelsdkLogin, LostintravelsdkLoginUserMutationCompanion, LostintravelsdkLoginUserMutation, LostintravelsdkLoginUserMutationLoginUser, LostintravelsdkLoginUserMutationData, LostintravelsdkApollo_apiHttpRequest, LostintravelsdkApollo_apiHttpResponse, LostintravelsdkApollo_apiOptional<__covariant V>, LostintravelsdkLocationInput, LostintravelsdkLocationCompanion, LostintravelsdkApollo_apiObjectType, LostintravelsdkLoginResponseCompanion, LostintravelsdkMutationCompanion, LostintravelsdkTimestampCompanion, LostintravelsdkApollo_apiCustomScalarType, LostintravelsdkUserCompanion, LostintravelsdkCreateUser_InputAdapter, LostintravelsdkLocationInput_InputAdapter, LostintravelsdkLogin_InputAdapter, LostintravelsdkUser_, LostintravelsdkDataState<T>, LostintravelsdkCommonFlow<T>, LostintravelsdkUserModel, LostintravelsdkServiceImpl, LostintravelsdkLoginResponse_, LostintravelsdkCreateNewUserMutationSelections, LostintravelsdkApollo_apiCompiledSelection, LostintravelsdkLoginUserMutationSelections, LostintravelsdkCreateNewUserMutation_ResponseAdapter, LostintravelsdkCreateNewUserMutation_ResponseAdapterCreateNewUser, LostintravelsdkCreateNewUserMutation_ResponseAdapterData, LostintravelsdkCreateNewUserMutation_ResponseAdapterLocation, LostintravelsdkCreateNewUserMutation_VariablesAdapter, LostintravelsdkLoginUserMutation_ResponseAdapter, LostintravelsdkLoginUserMutation_ResponseAdapterData, LostintravelsdkLoginUserMutation_ResponseAdapterLoginUser, LostintravelsdkLoginUserMutation_VariablesAdapter, LostintravelsdkApollo_apiError, LostintravelsdkDataStateCompanion, LostintravelsdkKtor_client_coreHttpClient, LostintravelsdkApollo_runtimeApolloClient, LostintravelsdkApiResponse<T>, LostintravelsdkLocation_Companion, LostintravelsdkLocation_, LostintravelsdkLoginResponse_Companion, LostintravelsdkUser_Companion, LostintravelsdkUserDataCompanion, LostintravelsdkUserData, LostintravelsdkKotlinThrowable, LostintravelsdkKotlinArray<T>, LostintravelsdkKotlinException, LostintravelsdkApollo_apiExecutableVariables, LostintravelsdkApollo_apiCompiledFieldBuilder, LostintravelsdkApollo_apiCompiledArgument, LostintravelsdkApollo_apiCompiledCondition, LostintravelsdkApollo_apiCompiledType, LostintravelsdkApollo_apiJsonNumber, LostintravelsdkApollo_apiCustomScalarAdaptersKey, LostintravelsdkApollo_apiCustomScalarAdaptersBuilder, LostintravelsdkKotlinRuntimeException, LostintravelsdkKotlinIllegalStateException, LostintravelsdkApollo_apiHttpRequestBuilder, LostintravelsdkApollo_apiHttpHeader, LostintravelsdkApollo_apiHttpMethod, LostintravelsdkApollo_apiHttpResponseBuilder, LostintravelsdkApollo_apiOptionalCompanion, LostintravelsdkApollo_apiCompiledNamedType, LostintravelsdkApollo_apiInterfaceType, LostintravelsdkKotlinNothing, LostintravelsdkApollo_apiJsonReaderToken, LostintravelsdkApollo_apiErrorLocation, LostintravelsdkKtor_client_coreHttpClientEngineConfig, LostintravelsdkKtor_client_coreHttpClientConfig<T>, LostintravelsdkKtor_eventsEvents, LostintravelsdkKtor_client_coreHttpReceivePipeline, LostintravelsdkKtor_client_coreHttpRequestPipeline, LostintravelsdkKtor_client_coreHttpResponsePipeline, LostintravelsdkKtor_client_coreHttpSendPipeline, LostintravelsdkApollo_runtimeApolloClientCompanion, LostintravelsdkApollo_apiApolloRequest<D>, LostintravelsdkApollo_runtimeApolloCall<D>, LostintravelsdkApollo_runtimeApolloClientBuilder, LostintravelsdkKotlinEnumCompanion, LostintravelsdkKotlinEnum<E>, LostintravelsdkOkioByteString, LostintravelsdkKotlinByteArray, LostintravelsdkOkioBuffer, LostintravelsdkOkioTimeout, LostintravelsdkKtor_client_coreHttpRequestData, LostintravelsdkKtor_client_coreHttpResponseData, LostintravelsdkKotlinx_coroutines_coreCoroutineDispatcher, LostintravelsdkKtor_client_coreProxyConfig, LostintravelsdkKtor_utilsAttributeKey<T>, LostintravelsdkKtor_eventsEventDefinition<T>, LostintravelsdkKtor_utilsPipelinePhase, LostintravelsdkKtor_utilsPipeline<TSubject, TContext>, LostintravelsdkKtor_client_coreHttpReceivePipelinePhases, LostintravelsdkKtor_client_coreHttpResponse, LostintravelsdkKotlinUnit, LostintravelsdkKtor_client_coreHttpRequestPipelinePhases, LostintravelsdkKtor_client_coreHttpRequestBuilder, LostintravelsdkKtor_client_coreHttpResponsePipelinePhases, LostintravelsdkKtor_client_coreHttpResponseContainer, LostintravelsdkKtor_client_coreHttpClientCall, LostintravelsdkKtor_client_coreHttpSendPipelinePhases, LostintravelsdkApollo_apiApolloRequestBuilder<D>, LostintravelsdkUuidUuid, LostintravelsdkApollo_apiApolloResponse<D>, LostintravelsdkKotlinx_serialization_coreSerializersModule, LostintravelsdkKotlinx_serialization_coreSerialKind, LostintravelsdkApollo_apiCustomTypeValue<T>, LostintravelsdkOkioByteStringCompanion, LostintravelsdkKotlinByteIterator, LostintravelsdkOkioBufferUnsafeCursor, LostintravelsdkOkioTimeoutCompanion, LostintravelsdkKtor_httpUrl, LostintravelsdkKtor_httpHttpMethod, LostintravelsdkKtor_httpOutgoingContent, LostintravelsdkKtor_httpHttpStatusCode, LostintravelsdkKtor_utilsGMTDate, LostintravelsdkKtor_httpHttpProtocolVersion, LostintravelsdkKotlinAbstractCoroutineContextElement, LostintravelsdkKotlinx_coroutines_coreCoroutineDispatcherKey, LostintravelsdkKtor_httpHeadersBuilder, LostintravelsdkKtor_client_coreHttpRequestBuilderCompanion, LostintravelsdkKtor_httpURLBuilder, LostintravelsdkKtor_utilsTypeInfo, LostintravelsdkKtor_client_coreHttpClientCallCompanion, LostintravelsdkApollo_apiApolloResponseBuilder<D>, LostintravelsdkApollo_runtimeWsProtocol, LostintravelsdkApollo_apiCustomTypeValueCompanion, LostintravelsdkKtor_httpUrlCompanion, LostintravelsdkKtor_httpURLProtocol, LostintravelsdkKtor_httpHttpMethodCompanion, LostintravelsdkKtor_httpContentType, LostintravelsdkKotlinCancellationException, LostintravelsdkKtor_httpHttpStatusCodeCompanion, LostintravelsdkKtor_utilsGMTDateCompanion, LostintravelsdkKtor_utilsWeekDay, LostintravelsdkKtor_utilsMonth, LostintravelsdkKtor_httpHttpProtocolVersionCompanion, LostintravelsdkKotlinAbstractCoroutineContextKey<B, E>, LostintravelsdkKtor_ioMemory, LostintravelsdkKtor_ioChunkBuffer, LostintravelsdkKtor_ioBuffer, LostintravelsdkKtor_ioByteReadPacket, LostintravelsdkKtor_utilsStringValuesBuilderImpl, LostintravelsdkKtor_httpURLBuilderCompanion, LostintravelsdkApollo_runtimeWsFrameType, LostintravelsdkKtor_httpURLProtocolCompanion, LostintravelsdkKtor_httpHeaderValueParam, LostintravelsdkKtor_httpHeaderValueWithParametersCompanion, LostintravelsdkKtor_httpHeaderValueWithParameters, LostintravelsdkKtor_httpContentTypeCompanion, LostintravelsdkKtor_utilsWeekDayCompanion, LostintravelsdkKtor_utilsMonthCompanion, LostintravelsdkKtor_ioMemoryCompanion, LostintravelsdkKtor_ioBufferCompanion, LostintravelsdkKtor_ioChunkBufferCompanion, LostintravelsdkKtor_ioInputCompanion, LostintravelsdkKtor_ioInput, LostintravelsdkKtor_ioByteReadPacketCompanion, LostintravelsdkKotlinKTypeProjection, LostintravelsdkKotlinx_coroutines_coreAtomicDesc, LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp, LostintravelsdkKotlinKVariance, LostintravelsdkKotlinKTypeProjectionCompanion, LostintravelsdkKotlinx_coroutines_coreAtomicOp<__contravariant T>, LostintravelsdkKotlinx_coroutines_coreOpDescriptor, LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode, LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc, LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc<T>, LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc<T>;

@protocol LostintravelsdkApollo_apiAdapter, LostintravelsdkApollo_apiJsonWriter, LostintravelsdkApollo_apiExecutable, LostintravelsdkApollo_apiOperation, LostintravelsdkApollo_apiMutation, LostintravelsdkApollo_apiExecutableData, LostintravelsdkApollo_apiOperationData, LostintravelsdkApollo_apiMutationData, LostintravelsdkApollo_runtimeHttpInterceptorChain, LostintravelsdkApollo_runtimeHttpInterceptor, LostintravelsdkApollo_apiJsonReader, LostintravelsdkKotlinx_coroutines_coreFlowCollector, LostintravelsdkKotlinx_coroutines_coreFlow, LostintravelsdkKotlinx_coroutines_coreCoroutineScope, LostintravelsdkAuthApiService, LostintravelsdkKotlinx_serialization_coreKSerializer, LostintravelsdkApollo_apiUpload, LostintravelsdkOkioCloseable, LostintravelsdkApollo_apiExecutionContextKey, LostintravelsdkApollo_apiExecutionContextElement, LostintravelsdkApollo_apiExecutionContext, LostintravelsdkApollo_apiHttpBody, LostintravelsdkOkioBufferedSource, LostintravelsdkKotlinCoroutineContext, LostintravelsdkKtor_ioCloseable, LostintravelsdkKtor_client_coreHttpClientEngine, LostintravelsdkKtor_client_coreHttpClientEngineCapability, LostintravelsdkKtor_utilsAttributes, LostintravelsdkApollo_apiExecutionOptions, LostintravelsdkApollo_apiQueryData, LostintravelsdkApollo_apiQuery, LostintravelsdkApollo_apiSubscriptionData, LostintravelsdkApollo_apiSubscription, LostintravelsdkApollo_runtimeApolloInterceptor, LostintravelsdkApollo_runtimeNetworkTransport, LostintravelsdkKotlinx_serialization_coreEncoder, LostintravelsdkKotlinx_serialization_coreSerialDescriptor, LostintravelsdkKotlinx_serialization_coreSerializationStrategy, LostintravelsdkKotlinx_serialization_coreDecoder, LostintravelsdkKotlinx_serialization_coreDeserializationStrategy, LostintravelsdkKotlinIterator, LostintravelsdkOkioBufferedSink, LostintravelsdkApollo_apiCustomTypeAdapter, LostintravelsdkKotlinComparable, LostintravelsdkOkioSink, LostintravelsdkOkioSource, LostintravelsdkKotlinCoroutineContextElement, LostintravelsdkKotlinCoroutineContextKey, LostintravelsdkKtor_client_coreHttpClientPlugin, LostintravelsdkKotlinx_coroutines_coreDisposableHandle, LostintravelsdkKotlinSuspendFunction2, LostintravelsdkApollo_apiMutableExecutionOptions, LostintravelsdkApollo_runtimeHttpEngine, LostintravelsdkApollo_runtimeWebSocketEngine, LostintravelsdkApollo_runtimeWsProtocolFactory, LostintravelsdkApollo_runtimeApolloInterceptorChain, LostintravelsdkKotlinx_serialization_coreCompositeEncoder, LostintravelsdkKotlinAnnotation, LostintravelsdkKotlinx_serialization_coreCompositeDecoder, LostintravelsdkKtor_httpHeaders, LostintravelsdkKotlinx_coroutines_coreJob, LostintravelsdkKotlinContinuation, LostintravelsdkKotlinContinuationInterceptor, LostintravelsdkKotlinx_coroutines_coreRunnable, LostintravelsdkKotlinFunction, LostintravelsdkKtor_httpHttpMessage, LostintravelsdkKtor_ioByteReadChannel, LostintravelsdkKtor_httpHttpMessageBuilder, LostintravelsdkKtor_client_coreHttpRequest, LostintravelsdkApollo_runtimeWebSocketConnection, LostintravelsdkApollo_runtimeWsProtocolListener, LostintravelsdkKotlinx_serialization_coreSerializersModuleCollector, LostintravelsdkKotlinKClass, LostintravelsdkKtor_httpParameters, LostintravelsdkKotlinMapEntry, LostintravelsdkKtor_utilsStringValues, LostintravelsdkKotlinx_coroutines_coreChildHandle, LostintravelsdkKotlinx_coroutines_coreChildJob, LostintravelsdkKotlinSequence, LostintravelsdkKotlinx_coroutines_coreSelectClause0, LostintravelsdkKtor_ioReadSession, LostintravelsdkKotlinSuspendFunction1, LostintravelsdkKotlinAppendable, LostintravelsdkKtor_utilsStringValuesBuilder, LostintravelsdkKtor_httpParametersBuilder, LostintravelsdkKotlinKType, LostintravelsdkKotlinKDeclarationContainer, LostintravelsdkKotlinKAnnotatedElement, LostintravelsdkKotlinKClassifier, LostintravelsdkKotlinx_coroutines_coreParentJob, LostintravelsdkKotlinx_coroutines_coreSelectInstance, LostintravelsdkKotlinSuspendFunction0, LostintravelsdkKtor_ioObjectPool;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface LostintravelsdkBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface LostintravelsdkBase (LostintravelsdkBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface LostintravelsdkMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface LostintravelsdkMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorLostintravelsdkKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface LostintravelsdkNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface LostintravelsdkByte : LostintravelsdkNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface LostintravelsdkUByte : LostintravelsdkNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface LostintravelsdkShort : LostintravelsdkNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface LostintravelsdkUShort : LostintravelsdkNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface LostintravelsdkInt : LostintravelsdkNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface LostintravelsdkUInt : LostintravelsdkNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface LostintravelsdkLong : LostintravelsdkNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface LostintravelsdkULong : LostintravelsdkNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface LostintravelsdkFloat : LostintravelsdkNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface LostintravelsdkDouble : LostintravelsdkNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface LostintravelsdkBoolean : LostintravelsdkNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((swift_name("Apollo_apiExecutable")))
@protocol LostintravelsdkApollo_apiExecutable
@required
- (id<LostintravelsdkApollo_apiAdapter>)adapter __attribute__((swift_name("adapter()")));
- (LostintravelsdkApollo_apiCompiledField *)rootField __attribute__((swift_name("rootField()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)serializeVariablesWriter:(id<LostintravelsdkApollo_apiJsonWriter>)writer customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("serializeVariables(writer:customScalarAdapters:)")));
@end

__attribute__((swift_name("Apollo_apiOperation")))
@protocol LostintravelsdkApollo_apiOperation <LostintravelsdkApollo_apiExecutable>
@required
- (NSString *)document __attribute__((swift_name("document()")));
- (NSString *)id __attribute__((swift_name("id()")));
- (NSString *)name __attribute__((swift_name("name()")));
@end

__attribute__((swift_name("Apollo_apiMutation")))
@protocol LostintravelsdkApollo_apiMutation <LostintravelsdkApollo_apiOperation>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateNewUserMutation")))
@interface LostintravelsdkCreateNewUserMutation : LostintravelsdkBase <LostintravelsdkApollo_apiMutation>
- (instancetype)initWithInput:(LostintravelsdkCreateUser *)input __attribute__((swift_name("init(input:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkCreateNewUserMutationCompanion *companion __attribute__((swift_name("companion")));
- (id<LostintravelsdkApollo_apiAdapter>)adapter __attribute__((swift_name("adapter()")));
- (LostintravelsdkCreateNewUserMutation *)doCopyInput:(LostintravelsdkCreateUser *)input __attribute__((swift_name("doCopy(input:)")));
- (NSString *)document __attribute__((swift_name("document()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)id __attribute__((swift_name("id()")));
- (NSString *)name __attribute__((swift_name("name()")));
- (LostintravelsdkApollo_apiCompiledField *)rootField __attribute__((swift_name("rootField()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)serializeVariablesWriter:(id<LostintravelsdkApollo_apiJsonWriter>)writer customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("serializeVariables(writer:customScalarAdapters:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) LostintravelsdkCreateUser *input __attribute__((swift_name("input")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateNewUserMutation.Companion")))
@interface LostintravelsdkCreateNewUserMutationCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkCreateNewUserMutationCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *OPERATION_DOCUMENT __attribute__((swift_name("OPERATION_DOCUMENT")));
@property (readonly) NSString *OPERATION_ID __attribute__((swift_name("OPERATION_ID")));
@property (readonly) NSString *OPERATION_NAME __attribute__((swift_name("OPERATION_NAME")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateNewUserMutation.CreateNewUser")))
@interface LostintravelsdkCreateNewUserMutationCreateNewUser : LostintravelsdkBase
- (instancetype)initWith_id:(NSString *)_id email:(NSString *)email picture:(NSString * _Nullable)picture full_name:(NSString *)full_name location:(LostintravelsdkCreateNewUserMutationLocation * _Nullable)location country:(NSString *)country is_verified:(BOOL)is_verified is_password_reset:(BOOL)is_password_reset created_at:(id)created_at updated_at:(id)updated_at __attribute__((swift_name("init(_id:email:picture:full_name:location:country:is_verified:is_password_reset:created_at:updated_at:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkCreateNewUserMutationCreateNewUser *)doCopy_id:(NSString *)_id email:(NSString *)email picture:(NSString * _Nullable)picture full_name:(NSString *)full_name location:(LostintravelsdkCreateNewUserMutationLocation * _Nullable)location country:(NSString *)country is_verified:(BOOL)is_verified is_password_reset:(BOOL)is_password_reset created_at:(id)created_at updated_at:(id)updated_at __attribute__((swift_name("doCopy(_id:email:picture:full_name:location:country:is_verified:is_password_reset:created_at:updated_at:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *_id __attribute__((swift_name("_id")));
@property (readonly) NSString *country __attribute__((swift_name("country")));
@property (readonly) id created_at __attribute__((swift_name("created_at")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) NSString *full_name __attribute__((swift_name("full_name")));
@property (readonly) BOOL is_password_reset __attribute__((swift_name("is_password_reset")));
@property (readonly) BOOL is_verified __attribute__((swift_name("is_verified")));
@property (readonly) LostintravelsdkCreateNewUserMutationLocation * _Nullable location __attribute__((swift_name("location")));
@property (readonly) NSString * _Nullable picture __attribute__((swift_name("picture")));
@property (readonly) id updated_at __attribute__((swift_name("updated_at")));
@end

__attribute__((swift_name("Apollo_apiExecutableData")))
@protocol LostintravelsdkApollo_apiExecutableData
@required
@end

__attribute__((swift_name("Apollo_apiOperationData")))
@protocol LostintravelsdkApollo_apiOperationData <LostintravelsdkApollo_apiExecutableData>
@required
@end

__attribute__((swift_name("Apollo_apiMutationData")))
@protocol LostintravelsdkApollo_apiMutationData <LostintravelsdkApollo_apiOperationData>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateNewUserMutation.Data")))
@interface LostintravelsdkCreateNewUserMutationData : LostintravelsdkBase <LostintravelsdkApollo_apiMutationData>
- (instancetype)initWithCreateNewUser:(LostintravelsdkCreateNewUserMutationCreateNewUser *)createNewUser __attribute__((swift_name("init(createNewUser:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkCreateNewUserMutationData *)doCopyCreateNewUser:(LostintravelsdkCreateNewUserMutationCreateNewUser *)createNewUser __attribute__((swift_name("doCopy(createNewUser:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) LostintravelsdkCreateNewUserMutationCreateNewUser *createNewUser __attribute__((swift_name("createNewUser")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateNewUserMutation.Location")))
@interface LostintravelsdkCreateNewUserMutationLocation : LostintravelsdkBase
- (instancetype)initWithLatitude:(NSString * _Nullable)latitude longitude:(NSString * _Nullable)longitude __attribute__((swift_name("init(latitude:longitude:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkCreateNewUserMutationLocation *)doCopyLatitude:(NSString * _Nullable)latitude longitude:(NSString * _Nullable)longitude __attribute__((swift_name("doCopy(latitude:longitude:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable latitude __attribute__((swift_name("latitude")));
@property (readonly) NSString * _Nullable longitude __attribute__((swift_name("longitude")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginUserMutation")))
@interface LostintravelsdkLoginUserMutation : LostintravelsdkBase <LostintravelsdkApollo_apiMutation>
- (instancetype)initWithInput:(LostintravelsdkLogin *)input __attribute__((swift_name("init(input:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkLoginUserMutationCompanion *companion __attribute__((swift_name("companion")));
- (id<LostintravelsdkApollo_apiAdapter>)adapter __attribute__((swift_name("adapter()")));
- (LostintravelsdkLoginUserMutation *)doCopyInput:(LostintravelsdkLogin *)input __attribute__((swift_name("doCopy(input:)")));
- (NSString *)document __attribute__((swift_name("document()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)id __attribute__((swift_name("id()")));
- (NSString *)name __attribute__((swift_name("name()")));
- (LostintravelsdkApollo_apiCompiledField *)rootField __attribute__((swift_name("rootField()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)serializeVariablesWriter:(id<LostintravelsdkApollo_apiJsonWriter>)writer customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("serializeVariables(writer:customScalarAdapters:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) LostintravelsdkLogin *input __attribute__((swift_name("input")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginUserMutation.Companion")))
@interface LostintravelsdkLoginUserMutationCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkLoginUserMutationCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *OPERATION_DOCUMENT __attribute__((swift_name("OPERATION_DOCUMENT")));
@property (readonly) NSString *OPERATION_ID __attribute__((swift_name("OPERATION_ID")));
@property (readonly) NSString *OPERATION_NAME __attribute__((swift_name("OPERATION_NAME")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginUserMutation.Data")))
@interface LostintravelsdkLoginUserMutationData : LostintravelsdkBase <LostintravelsdkApollo_apiMutationData>
- (instancetype)initWithLoginUser:(LostintravelsdkLoginUserMutationLoginUser * _Nullable)loginUser __attribute__((swift_name("init(loginUser:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkLoginUserMutationData *)doCopyLoginUser:(LostintravelsdkLoginUserMutationLoginUser * _Nullable)loginUser __attribute__((swift_name("doCopy(loginUser:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) LostintravelsdkLoginUserMutationLoginUser * _Nullable loginUser __attribute__((swift_name("loginUser")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginUserMutation.LoginUser")))
@interface LostintravelsdkLoginUserMutationLoginUser : LostintravelsdkBase
- (instancetype)initWithToken:(NSString *)token __attribute__((swift_name("init(token:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkLoginUserMutationLoginUser *)doCopyToken:(NSString *)token __attribute__((swift_name("doCopy(token:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *token __attribute__((swift_name("token")));
@end

__attribute__((swift_name("Apollo_runtimeHttpInterceptor")))
@protocol LostintravelsdkApollo_runtimeHttpInterceptor
@required
- (void)dispose __attribute__((swift_name("dispose()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)interceptRequest:(LostintravelsdkApollo_apiHttpRequest *)request chain:(id<LostintravelsdkApollo_runtimeHttpInterceptorChain>)chain completionHandler:(void (^)(LostintravelsdkApollo_apiHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("intercept(request:chain:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ResponseInterceptor")))
@interface LostintravelsdkResponseInterceptor : LostintravelsdkBase <LostintravelsdkApollo_runtimeHttpInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)interceptRequest:(LostintravelsdkApollo_apiHttpRequest *)request chain:(id<LostintravelsdkApollo_runtimeHttpInterceptorChain>)chain completionHandler:(void (^)(LostintravelsdkApollo_apiHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("intercept(request:chain:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateUser")))
@interface LostintravelsdkCreateUser : LostintravelsdkBase
- (instancetype)initWithEmail:(NSString *)email picture:(LostintravelsdkApollo_apiOptional<NSString *> *)picture full_name:(NSString *)full_name location:(LostintravelsdkLocationInput *)location password:(NSString *)password __attribute__((swift_name("init(email:picture:full_name:location:password:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkCreateUser *)doCopyEmail:(NSString *)email picture:(LostintravelsdkApollo_apiOptional<NSString *> *)picture full_name:(NSString *)full_name location:(LostintravelsdkLocationInput *)location password:(NSString *)password __attribute__((swift_name("doCopy(email:picture:full_name:location:password:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) NSString *full_name __attribute__((swift_name("full_name")));
@property (readonly) LostintravelsdkLocationInput *location __attribute__((swift_name("location")));
@property (readonly) NSString *password __attribute__((swift_name("password")));
@property (readonly) LostintravelsdkApollo_apiOptional<NSString *> *picture __attribute__((swift_name("picture")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Location")))
@interface LostintravelsdkLocation : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) LostintravelsdkLocationCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Location.Companion")))
@interface LostintravelsdkLocationCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkLocationCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkApollo_apiObjectType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LocationInput")))
@interface LostintravelsdkLocationInput : LostintravelsdkBase
- (instancetype)initWithLatitude:(NSString *)latitude longitude:(NSString *)longitude __attribute__((swift_name("init(latitude:longitude:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkLocationInput *)doCopyLatitude:(NSString *)latitude longitude:(NSString *)longitude __attribute__((swift_name("doCopy(latitude:longitude:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *latitude __attribute__((swift_name("latitude")));
@property (readonly) NSString *longitude __attribute__((swift_name("longitude")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Login")))
@interface LostintravelsdkLogin : LostintravelsdkBase
- (instancetype)initWithEmail:(NSString *)email password:(NSString *)password __attribute__((swift_name("init(email:password:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkLogin *)doCopyEmail:(NSString *)email password:(NSString *)password __attribute__((swift_name("doCopy(email:password:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) NSString *password __attribute__((swift_name("password")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginResponse")))
@interface LostintravelsdkLoginResponse : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) LostintravelsdkLoginResponseCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginResponse.Companion")))
@interface LostintravelsdkLoginResponseCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkLoginResponseCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkApollo_apiObjectType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Mutation")))
@interface LostintravelsdkMutation : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) LostintravelsdkMutationCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Mutation.Companion")))
@interface LostintravelsdkMutationCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkMutationCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkApollo_apiObjectType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Timestamp")))
@interface LostintravelsdkTimestamp : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) LostintravelsdkTimestampCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Timestamp.Companion")))
@interface LostintravelsdkTimestampCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkTimestampCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkApollo_apiCustomScalarType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("User")))
@interface LostintravelsdkUser : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) LostintravelsdkUserCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("User.Companion")))
@interface LostintravelsdkUserCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkUserCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkApollo_apiObjectType *type __attribute__((swift_name("type")));
@end

__attribute__((swift_name("Apollo_apiAdapter")))
@protocol LostintravelsdkApollo_apiAdapter
@required

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id _Nullable)fromJsonReader:(id<LostintravelsdkApollo_apiJsonReader>)reader customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<LostintravelsdkApollo_apiJsonWriter>)writer customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters value:(id _Nullable)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateUser_InputAdapter")))
@interface LostintravelsdkCreateUser_InputAdapter : LostintravelsdkBase <LostintravelsdkApollo_apiAdapter>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)createUser_InputAdapter __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkCreateUser_InputAdapter *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (LostintravelsdkCreateUser * _Nullable)fromJsonReader:(id<LostintravelsdkApollo_apiJsonReader>)reader customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<LostintravelsdkApollo_apiJsonWriter>)writer customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters value:(LostintravelsdkCreateUser *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LocationInput_InputAdapter")))
@interface LostintravelsdkLocationInput_InputAdapter : LostintravelsdkBase <LostintravelsdkApollo_apiAdapter>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)locationInput_InputAdapter __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkLocationInput_InputAdapter *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (LostintravelsdkLocationInput * _Nullable)fromJsonReader:(id<LostintravelsdkApollo_apiJsonReader>)reader customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<LostintravelsdkApollo_apiJsonWriter>)writer customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters value:(LostintravelsdkLocationInput *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Login_InputAdapter")))
@interface LostintravelsdkLogin_InputAdapter : LostintravelsdkBase <LostintravelsdkApollo_apiAdapter>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)login_InputAdapter __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkLogin_InputAdapter *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (LostintravelsdkLogin * _Nullable)fromJsonReader:(id<LostintravelsdkApollo_apiJsonReader>)reader customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<LostintravelsdkApollo_apiJsonWriter>)writer customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters value:(LostintravelsdkLogin *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateUserUseCase")))
@interface LostintravelsdkCreateUserUseCase : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (LostintravelsdkCommonFlow<LostintravelsdkDataState<LostintravelsdkUser_ *> *> *)executeUserModel:(LostintravelsdkUserModel *)userModel __attribute__((swift_name("execute(userModel:)")));
- (LostintravelsdkServiceImpl *)getApiService __attribute__((swift_name("getApiService()")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginUserUseCase")))
@interface LostintravelsdkLoginUserUseCase : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (LostintravelsdkCommonFlow<LostintravelsdkDataState<LostintravelsdkLoginResponse_ *> *> *)executeUserModel:(LostintravelsdkUserModel *)userModel __attribute__((swift_name("execute(userModel:)")));
- (LostintravelsdkServiceImpl *)getApiService __attribute__((swift_name("getApiService()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateNewUserMutationSelections")))
@interface LostintravelsdkCreateNewUserMutationSelections : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)createNewUserMutationSelections __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkCreateNewUserMutationSelections *shared __attribute__((swift_name("shared")));
@property (readonly) NSArray<LostintravelsdkApollo_apiCompiledSelection *> *root __attribute__((swift_name("root")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginUserMutationSelections")))
@interface LostintravelsdkLoginUserMutationSelections : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)loginUserMutationSelections __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkLoginUserMutationSelections *shared __attribute__((swift_name("shared")));
@property (readonly) NSArray<LostintravelsdkApollo_apiCompiledSelection *> *root __attribute__((swift_name("root")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateNewUserMutation_ResponseAdapter")))
@interface LostintravelsdkCreateNewUserMutation_ResponseAdapter : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)createNewUserMutation_ResponseAdapter __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkCreateNewUserMutation_ResponseAdapter *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateNewUserMutation_ResponseAdapter.CreateNewUser")))
@interface LostintravelsdkCreateNewUserMutation_ResponseAdapterCreateNewUser : LostintravelsdkBase <LostintravelsdkApollo_apiAdapter>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)createNewUser __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkCreateNewUserMutation_ResponseAdapterCreateNewUser *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (LostintravelsdkCreateNewUserMutationCreateNewUser * _Nullable)fromJsonReader:(id<LostintravelsdkApollo_apiJsonReader>)reader customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<LostintravelsdkApollo_apiJsonWriter>)writer customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters value:(LostintravelsdkCreateNewUserMutationCreateNewUser *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@property (readonly) NSArray<NSString *> *RESPONSE_NAMES __attribute__((swift_name("RESPONSE_NAMES")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateNewUserMutation_ResponseAdapter.Data")))
@interface LostintravelsdkCreateNewUserMutation_ResponseAdapterData : LostintravelsdkBase <LostintravelsdkApollo_apiAdapter>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)data __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkCreateNewUserMutation_ResponseAdapterData *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (LostintravelsdkCreateNewUserMutationData * _Nullable)fromJsonReader:(id<LostintravelsdkApollo_apiJsonReader>)reader customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<LostintravelsdkApollo_apiJsonWriter>)writer customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters value:(LostintravelsdkCreateNewUserMutationData *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@property (readonly) NSArray<NSString *> *RESPONSE_NAMES __attribute__((swift_name("RESPONSE_NAMES")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateNewUserMutation_ResponseAdapter.Location")))
@interface LostintravelsdkCreateNewUserMutation_ResponseAdapterLocation : LostintravelsdkBase <LostintravelsdkApollo_apiAdapter>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)location __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkCreateNewUserMutation_ResponseAdapterLocation *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (LostintravelsdkCreateNewUserMutationLocation * _Nullable)fromJsonReader:(id<LostintravelsdkApollo_apiJsonReader>)reader customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<LostintravelsdkApollo_apiJsonWriter>)writer customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters value:(LostintravelsdkCreateNewUserMutationLocation *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@property (readonly) NSArray<NSString *> *RESPONSE_NAMES __attribute__((swift_name("RESPONSE_NAMES")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateNewUserMutation_VariablesAdapter")))
@interface LostintravelsdkCreateNewUserMutation_VariablesAdapter : LostintravelsdkBase <LostintravelsdkApollo_apiAdapter>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)createNewUserMutation_VariablesAdapter __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkCreateNewUserMutation_VariablesAdapter *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (LostintravelsdkCreateNewUserMutation * _Nullable)fromJsonReader:(id<LostintravelsdkApollo_apiJsonReader>)reader customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<LostintravelsdkApollo_apiJsonWriter>)writer customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters value:(LostintravelsdkCreateNewUserMutation *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginUserMutation_ResponseAdapter")))
@interface LostintravelsdkLoginUserMutation_ResponseAdapter : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)loginUserMutation_ResponseAdapter __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkLoginUserMutation_ResponseAdapter *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginUserMutation_ResponseAdapter.Data")))
@interface LostintravelsdkLoginUserMutation_ResponseAdapterData : LostintravelsdkBase <LostintravelsdkApollo_apiAdapter>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)data __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkLoginUserMutation_ResponseAdapterData *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (LostintravelsdkLoginUserMutationData * _Nullable)fromJsonReader:(id<LostintravelsdkApollo_apiJsonReader>)reader customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<LostintravelsdkApollo_apiJsonWriter>)writer customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters value:(LostintravelsdkLoginUserMutationData *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@property (readonly) NSArray<NSString *> *RESPONSE_NAMES __attribute__((swift_name("RESPONSE_NAMES")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginUserMutation_ResponseAdapter.LoginUser")))
@interface LostintravelsdkLoginUserMutation_ResponseAdapterLoginUser : LostintravelsdkBase <LostintravelsdkApollo_apiAdapter>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)loginUser __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkLoginUserMutation_ResponseAdapterLoginUser *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (LostintravelsdkLoginUserMutationLoginUser * _Nullable)fromJsonReader:(id<LostintravelsdkApollo_apiJsonReader>)reader customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<LostintravelsdkApollo_apiJsonWriter>)writer customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters value:(LostintravelsdkLoginUserMutationLoginUser *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@property (readonly) NSArray<NSString *> *RESPONSE_NAMES __attribute__((swift_name("RESPONSE_NAMES")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginUserMutation_VariablesAdapter")))
@interface LostintravelsdkLoginUserMutation_VariablesAdapter : LostintravelsdkBase <LostintravelsdkApollo_apiAdapter>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)loginUserMutation_VariablesAdapter __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkLoginUserMutation_VariablesAdapter *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (LostintravelsdkLoginUserMutation * _Nullable)fromJsonReader:(id<LostintravelsdkApollo_apiJsonReader>)reader customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<LostintravelsdkApollo_apiJsonWriter>)writer customScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters value:(LostintravelsdkLoginUserMutation *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol LostintravelsdkKotlinx_coroutines_coreFlow
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<LostintravelsdkKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CommonFlow")))
@interface LostintravelsdkCommonFlow<T> : LostintravelsdkBase <LostintravelsdkKotlinx_coroutines_coreFlow>
- (instancetype)initWithOrigin:(id<LostintravelsdkKotlinx_coroutines_coreFlow>)origin __attribute__((swift_name("init(origin:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<LostintravelsdkKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
- (void)collectCommonCoroutineScope:(id<LostintravelsdkKotlinx_coroutines_coreCoroutineScope> _Nullable)coroutineScope callback:(void (^)(T _Nullable))callback __attribute__((swift_name("collectCommon(coroutineScope:callback:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DataState")))
@interface LostintravelsdkDataState<T> : LostintravelsdkBase
- (instancetype)initWithErrors:(NSArray<LostintravelsdkApollo_apiError *> * _Nullable)errors data:(T _Nullable)data isLoading:(BOOL)isLoading success:(BOOL)success __attribute__((swift_name("init(errors:data:isLoading:success:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkDataStateCompanion *companion __attribute__((swift_name("companion")));
- (LostintravelsdkDataState<T> *)doCopyErrors:(NSArray<LostintravelsdkApollo_apiError *> * _Nullable)errors data:(T _Nullable)data isLoading:(BOOL)isLoading success:(BOOL)success __attribute__((swift_name("doCopy(errors:data:isLoading:success:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) T _Nullable data __attribute__((swift_name("data")));
@property (readonly) NSArray<LostintravelsdkApollo_apiError *> * _Nullable errors __attribute__((swift_name("errors")));
@property (readonly) BOOL isLoading __attribute__((swift_name("isLoading")));
@property (readonly) BOOL success __attribute__((swift_name("success")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DataStateCompanion")))
@interface LostintravelsdkDataStateCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkDataStateCompanion *shared __attribute__((swift_name("shared")));
- (LostintravelsdkDataState<id> *)dataErrors:(NSArray<LostintravelsdkApollo_apiError *> * _Nullable)errors data:(id _Nullable)data success:(BOOL)success __attribute__((swift_name("data(errors:data:success:)")));
- (LostintravelsdkDataState<id> *)errorErrors:(NSArray<LostintravelsdkApollo_apiError *> * _Nullable)errors __attribute__((swift_name("error(errors:)")));
- (LostintravelsdkDataState<id> *)loading __attribute__((swift_name("loading()")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiClientFactory")))
@interface LostintravelsdkApiClientFactory : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (LostintravelsdkKtor_client_coreHttpClient *)build __attribute__((swift_name("build()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo")))
@interface LostintravelsdkApollo : LostintravelsdkBase
- (instancetype)initWithToken:(NSString *)token __attribute__((swift_name("init(token:)"))) __attribute__((objc_designated_initializer));
@property (readonly) LostintravelsdkApollo_runtimeApolloClient *apolloClient __attribute__((swift_name("apolloClient")));
@end

__attribute__((swift_name("AuthApiService")))
@protocol LostintravelsdkAuthApiService
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createUserUserModel:(LostintravelsdkUserModel *)userModel completionHandler:(void (^)(LostintravelsdkApiResponse<LostintravelsdkUser_ *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createUser(userModel:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)loginUserUserModel:(LostintravelsdkUserModel *)userModel completionHandler:(void (^)(LostintravelsdkApiResponse<LostintravelsdkLoginResponse_ *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("loginUser(userModel:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthorizationInterceptor")))
@interface LostintravelsdkAuthorizationInterceptor : LostintravelsdkBase <LostintravelsdkApollo_runtimeHttpInterceptor>
- (instancetype)initWithToken:(NSString *)token __attribute__((swift_name("init(token:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)interceptRequest:(LostintravelsdkApollo_apiHttpRequest *)request chain:(id<LostintravelsdkApollo_runtimeHttpInterceptorChain>)chain completionHandler:(void (^)(LostintravelsdkApollo_apiHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("intercept(request:chain:completionHandler:)")));
@property (readonly) NSString *token __attribute__((swift_name("token")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ServiceImpl")))
@interface LostintravelsdkServiceImpl : LostintravelsdkBase <LostintravelsdkAuthApiService>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createUserUserModel:(LostintravelsdkUserModel *)userModel completionHandler:(void (^)(LostintravelsdkApiResponse<LostintravelsdkUser_ *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createUser(userModel:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)loginUserUserModel:(LostintravelsdkUserModel *)userModel completionHandler:(void (^)(LostintravelsdkApiResponse<LostintravelsdkLoginResponse_ *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("loginUser(userModel:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiResponse")))
@interface LostintravelsdkApiResponse<T> : LostintravelsdkBase
- (instancetype)initWithStatusCode:(LostintravelsdkInt * _Nullable)statusCode errors:(NSArray<LostintravelsdkApollo_apiError *> * _Nullable)errors data:(T _Nullable)data error:(BOOL)error __attribute__((swift_name("init(statusCode:errors:data:error:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkApiResponse<T> *)doCopyStatusCode:(LostintravelsdkInt * _Nullable)statusCode errors:(NSArray<LostintravelsdkApollo_apiError *> * _Nullable)errors data:(T _Nullable)data error:(BOOL)error __attribute__((swift_name("doCopy(statusCode:errors:data:error:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) T _Nullable data __attribute__((swift_name("data")));
@property (readonly) BOOL error __attribute__((swift_name("error")));
@property (readonly) NSArray<LostintravelsdkApollo_apiError *> * _Nullable errors __attribute__((swift_name("errors")));
@property (readonly) LostintravelsdkInt * _Nullable statusCode __attribute__((swift_name("statusCode")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Location_")))
@interface LostintravelsdkLocation_ : LostintravelsdkBase
- (instancetype)initWithLatitude:(NSString *)latitude longitude:(NSString *)longitude __attribute__((swift_name("init(latitude:longitude:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkLocation_Companion *companion __attribute__((swift_name("companion")));
- (LostintravelsdkLocation_ *)doCopyLatitude:(NSString *)latitude longitude:(NSString *)longitude __attribute__((swift_name("doCopy(latitude:longitude:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *latitude __attribute__((swift_name("latitude")));
@property (readonly) NSString *longitude __attribute__((swift_name("longitude")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Location_.Companion")))
@interface LostintravelsdkLocation_Companion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkLocation_Companion *shared __attribute__((swift_name("shared")));
- (id<LostintravelsdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginResponse_")))
@interface LostintravelsdkLoginResponse_ : LostintravelsdkBase
- (instancetype)initWithToken:(NSString *)token __attribute__((swift_name("init(token:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkLoginResponse_Companion *companion __attribute__((swift_name("companion")));
- (LostintravelsdkLoginResponse_ *)doCopyToken:(NSString *)token __attribute__((swift_name("doCopy(token:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *token __attribute__((swift_name("token")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginResponse_.Companion")))
@interface LostintravelsdkLoginResponse_Companion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkLoginResponse_Companion *shared __attribute__((swift_name("shared")));
- (id<LostintravelsdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("User_")))
@interface LostintravelsdkUser_ : LostintravelsdkBase
- (instancetype)initWith_id:(NSString *)_id country:(NSString *)country created_at:(NSString *)created_at email:(NSString *)email full_name:(NSString *)full_name password:(NSString *)password is_password_reset:(BOOL)is_password_reset is_verified:(BOOL)is_verified location:(LostintravelsdkLocation_ *)location updated_at:(NSString *)updated_at __attribute__((swift_name("init(_id:country:created_at:email:full_name:password:is_password_reset:is_verified:location:updated_at:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkUser_Companion *companion __attribute__((swift_name("companion")));
- (LostintravelsdkUser_ *)doCopy_id:(NSString *)_id country:(NSString *)country created_at:(NSString *)created_at email:(NSString *)email full_name:(NSString *)full_name password:(NSString *)password is_password_reset:(BOOL)is_password_reset is_verified:(BOOL)is_verified location:(LostintravelsdkLocation_ *)location updated_at:(NSString *)updated_at __attribute__((swift_name("doCopy(_id:country:created_at:email:full_name:password:is_password_reset:is_verified:location:updated_at:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *_id __attribute__((swift_name("_id")));
@property (readonly) NSString *country __attribute__((swift_name("country")));
@property (readonly) NSString *created_at __attribute__((swift_name("created_at")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) NSString *full_name __attribute__((swift_name("full_name")));
@property (readonly) BOOL is_password_reset __attribute__((swift_name("is_password_reset")));
@property (readonly) BOOL is_verified __attribute__((swift_name("is_verified")));
@property (readonly) LostintravelsdkLocation_ *location __attribute__((swift_name("location")));
@property (readonly) NSString *password __attribute__((swift_name("password")));
@property (readonly) NSString *updated_at __attribute__((swift_name("updated_at")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("User_.Companion")))
@interface LostintravelsdkUser_Companion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkUser_Companion *shared __attribute__((swift_name("shared")));
- (id<LostintravelsdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserData")))
@interface LostintravelsdkUserData : LostintravelsdkBase
- (instancetype)initWithToken:(NSString *)token user:(LostintravelsdkUser_ *)user __attribute__((swift_name("init(token:user:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkUserDataCompanion *companion __attribute__((swift_name("companion")));
- (LostintravelsdkUserData *)doCopyToken:(NSString *)token user:(LostintravelsdkUser_ *)user __attribute__((swift_name("doCopy(token:user:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *token __attribute__((swift_name("token")));
@property (readonly) LostintravelsdkUser_ *user __attribute__((swift_name("user")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserData.Companion")))
@interface LostintravelsdkUserDataCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkUserDataCompanion *shared __attribute__((swift_name("shared")));
- (id<LostintravelsdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserModel")))
@interface LostintravelsdkUserModel : LostintravelsdkBase
- (instancetype)initWithFullName:(NSString * _Nullable)fullName email:(NSString *)email phoneNumber:(NSString * _Nullable)phoneNumber password:(NSString * _Nullable)password country:(NSString * _Nullable)country location:(LostintravelsdkLocation_ *)location __attribute__((swift_name("init(fullName:email:phoneNumber:password:country:location:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkUserModel *)doCopyFullName:(NSString * _Nullable)fullName email:(NSString *)email phoneNumber:(NSString * _Nullable)phoneNumber password:(NSString * _Nullable)password country:(NSString * _Nullable)country location:(LostintravelsdkLocation_ *)location __attribute__((swift_name("doCopy(fullName:email:phoneNumber:password:country:location:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable country __attribute__((swift_name("country")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) NSString * _Nullable fullName __attribute__((swift_name("fullName")));
@property (readonly) LostintravelsdkLocation_ *location __attribute__((swift_name("location")));
@property (readonly) NSString * _Nullable password __attribute__((swift_name("password")));
@property (readonly) NSString * _Nullable phoneNumber __attribute__((swift_name("phoneNumber")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AsCommonFlowKt")))
@interface LostintravelsdkAsCommonFlowKt : LostintravelsdkBase
+ (LostintravelsdkCommonFlow<id> *)asCommonFlow:(id<LostintravelsdkKotlinx_coroutines_coreFlow>)receiver __attribute__((swift_name("asCommonFlow(_:)")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface LostintravelsdkKotlinThrowable : LostintravelsdkBase
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(LostintravelsdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(LostintravelsdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) LostintravelsdkKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface LostintravelsdkKotlinException : LostintravelsdkKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(LostintravelsdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(LostintravelsdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("OkioIOException")))
@interface LostintravelsdkOkioIOException : LostintravelsdkKotlinException
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(LostintravelsdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithCause:(LostintravelsdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((swift_name("Apollo_apiCompiledSelection")))
@interface LostintravelsdkApollo_apiCompiledSelection : LostintravelsdkBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCompiledField")))
@interface LostintravelsdkApollo_apiCompiledField : LostintravelsdkApollo_apiCompiledSelection
- (NSString *)nameWithArgumentsVariables:(LostintravelsdkApollo_apiExecutableVariables *)variables __attribute__((swift_name("nameWithArguments(variables:)")));
- (LostintravelsdkApollo_apiCompiledFieldBuilder *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));
- (id _Nullable)resolveArgumentName:(NSString *)name variables:(LostintravelsdkApollo_apiExecutableVariables *)variables __attribute__((swift_name("resolveArgument(name:variables:)")));
@property (readonly) NSString * _Nullable alias __attribute__((swift_name("alias")));
@property (readonly) NSArray<LostintravelsdkApollo_apiCompiledArgument *> *arguments __attribute__((swift_name("arguments")));
@property (readonly) NSArray<LostintravelsdkApollo_apiCompiledCondition *> *condition __attribute__((swift_name("condition")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *responseName __attribute__((swift_name("responseName")));
@property (readonly) NSArray<LostintravelsdkApollo_apiCompiledSelection *> *selections __attribute__((swift_name("selections")));
@property (readonly) LostintravelsdkApollo_apiCompiledType *type __attribute__((swift_name("type")));
@end

__attribute__((swift_name("OkioCloseable")))
@protocol LostintravelsdkOkioCloseable
@required

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)closeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("close()")));
@end

__attribute__((swift_name("Apollo_apiJsonWriter")))
@protocol LostintravelsdkApollo_apiJsonWriter <LostintravelsdkOkioCloseable>
@required

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonWriter> _Nullable)beginArrayAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("beginArray()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonWriter> _Nullable)beginObjectAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("beginObject()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonWriter> _Nullable)endArrayAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("endArray()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonWriter> _Nullable)endObjectAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("endObject()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)flushAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("flush()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonWriter> _Nullable)nameName:(NSString *)name error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("name(name:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonWriter> _Nullable)nullValueAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nullValue()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonWriter> _Nullable)valueValue:(id<LostintravelsdkApollo_apiUpload>)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("value(value:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonWriter> _Nullable)valueValue:(LostintravelsdkApollo_apiJsonNumber *)value error_:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("value(value_:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonWriter> _Nullable)valueValue:(BOOL)value error__:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("value(value__:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonWriter> _Nullable)valueValue:(double)value error___:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("value(value___:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonWriter> _Nullable)valueValue:(int32_t)value error____:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("value(value____:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonWriter> _Nullable)valueValue:(int64_t)value error_____:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("value(value_____:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonWriter> _Nullable)valueValue:(NSString *)value error______:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("value(value______:)")));
@property (readonly) NSString *path __attribute__((swift_name("path")));
@end

__attribute__((swift_name("Apollo_apiExecutionContext")))
@protocol LostintravelsdkApollo_apiExecutionContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<LostintravelsdkApollo_apiExecutionContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<LostintravelsdkApollo_apiExecutionContextElement> _Nullable)getKey:(id<LostintravelsdkApollo_apiExecutionContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<LostintravelsdkApollo_apiExecutionContext>)minusKeyKey:(id<LostintravelsdkApollo_apiExecutionContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<LostintravelsdkApollo_apiExecutionContext>)plusContext:(id<LostintravelsdkApollo_apiExecutionContext>)context __attribute__((swift_name("plus(context:)")));
@end

__attribute__((swift_name("Apollo_apiExecutionContextElement")))
@protocol LostintravelsdkApollo_apiExecutionContextElement <LostintravelsdkApollo_apiExecutionContext>
@required
@property (readonly) id<LostintravelsdkApollo_apiExecutionContextKey> key __attribute__((swift_name("key")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCustomScalarAdapters")))
@interface LostintravelsdkApollo_apiCustomScalarAdapters : LostintravelsdkBase <LostintravelsdkApollo_apiExecutionContextElement>
@property (class, readonly, getter=companion) LostintravelsdkApollo_apiCustomScalarAdaptersKey *companion __attribute__((swift_name("companion")));
- (LostintravelsdkApollo_apiCustomScalarAdaptersBuilder *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));
- (id<LostintravelsdkApollo_apiAdapter>)responseAdapterForCustomScalar:(LostintravelsdkApollo_apiCustomScalarType *)customScalar __attribute__((swift_name("responseAdapterFor(customScalar:)")));
@property (readonly) id<LostintravelsdkApollo_apiExecutionContextKey> key __attribute__((swift_name("key")));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface LostintravelsdkKotlinRuntimeException : LostintravelsdkKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(LostintravelsdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(LostintravelsdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface LostintravelsdkKotlinIllegalStateException : LostintravelsdkKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(LostintravelsdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(LostintravelsdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface LostintravelsdkKotlinCancellationException : LostintravelsdkKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(LostintravelsdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(LostintravelsdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiHttpRequest")))
@interface LostintravelsdkApollo_apiHttpRequest : LostintravelsdkBase
- (LostintravelsdkApollo_apiHttpRequestBuilder *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));
@property (readonly) id<LostintravelsdkApollo_apiHttpBody> _Nullable body __attribute__((swift_name("body")));
@property (readonly) NSArray<LostintravelsdkApollo_apiHttpHeader *> *headers __attribute__((swift_name("headers")));
@property (readonly) LostintravelsdkApollo_apiHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end

__attribute__((swift_name("Apollo_runtimeHttpInterceptorChain")))
@protocol LostintravelsdkApollo_runtimeHttpInterceptorChain
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)proceedRequest:(LostintravelsdkApollo_apiHttpRequest *)request completionHandler:(void (^)(LostintravelsdkApollo_apiHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("proceed(request:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiHttpResponse")))
@interface LostintravelsdkApollo_apiHttpResponse : LostintravelsdkBase
- (LostintravelsdkApollo_apiHttpResponseBuilder *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));
@property (readonly) id<LostintravelsdkOkioBufferedSource> _Nullable body __attribute__((swift_name("body")));
@property (readonly) NSArray<LostintravelsdkApollo_apiHttpHeader *> *headers __attribute__((swift_name("headers")));
@property (readonly) int32_t statusCode __attribute__((swift_name("statusCode")));
@end

__attribute__((swift_name("Apollo_apiOptional")))
@interface LostintravelsdkApollo_apiOptional<__covariant V> : LostintravelsdkBase
@property (class, readonly, getter=companion) LostintravelsdkApollo_apiOptionalCompanion *companion __attribute__((swift_name("companion")));
- (V _Nullable)getOrNull __attribute__((swift_name("getOrNull()")));
- (V _Nullable)getOrThrow __attribute__((swift_name("getOrThrow()")));
@end

__attribute__((swift_name("Apollo_apiCompiledType")))
@interface LostintravelsdkApollo_apiCompiledType : LostintravelsdkBase
- (LostintravelsdkApollo_apiCompiledNamedType *)leafType __attribute__((swift_name("leafType()")));
@end

__attribute__((swift_name("Apollo_apiCompiledNamedType")))
@interface LostintravelsdkApollo_apiCompiledNamedType : LostintravelsdkApollo_apiCompiledType
- (LostintravelsdkApollo_apiCompiledNamedType *)leafType __attribute__((swift_name("leafType()")));
@property (readonly, getter=name_) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiObjectType")))
@interface LostintravelsdkApollo_apiObjectType : LostintravelsdkApollo_apiCompiledNamedType
- (instancetype)initWithName:(NSString *)name keyFields:(NSArray<NSString *> *)keyFields implements:(NSArray<LostintravelsdkApollo_apiInterfaceType *> *)implements __attribute__((swift_name("init(name:keyFields:implements:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSArray<LostintravelsdkApollo_apiInterfaceType *> *implements __attribute__((swift_name("implements")));
@property (readonly) NSArray<NSString *> *keyFields __attribute__((swift_name("keyFields")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCustomScalarType")))
@interface LostintravelsdkApollo_apiCustomScalarType : LostintravelsdkApollo_apiCompiledNamedType
- (instancetype)initWithName:(NSString *)name className:(NSString *)className __attribute__((swift_name("init(name:className:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *className __attribute__((swift_name("className")));
@end

__attribute__((swift_name("Apollo_apiJsonReader")))
@protocol LostintravelsdkApollo_apiJsonReader <LostintravelsdkOkioCloseable>
@required

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonReader> _Nullable)beginArrayAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("beginArray()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonReader> _Nullable)beginObjectAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("beginObject()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonReader> _Nullable)endArrayAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("endArray()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<LostintravelsdkApollo_apiJsonReader> _Nullable)endObjectAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("endObject()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)hasNextAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("hasNext()"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)nextBooleanAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextBoolean()"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (double)nextDoubleAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextDouble()"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (int32_t)nextIntAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextInt()"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (int64_t)nextLongAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextLong()"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (NSString * _Nullable)nextNameAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextName()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (LostintravelsdkKotlinNothing * _Nullable)nextNullAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextNull()"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (LostintravelsdkApollo_apiJsonNumber * _Nullable)nextNumberAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextNumber()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (NSString * _Nullable)nextStringAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextString()"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (LostintravelsdkApollo_apiJsonReaderToken * _Nullable)peekAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("peek()")));
- (void)rewind __attribute__((swift_name("rewind()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (int32_t)selectNameNames:(NSArray<NSString *> *)names error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("selectName(names:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)skipValueAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("skipValue()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol LostintravelsdkKotlinx_coroutines_coreFlowCollector
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol LostintravelsdkKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<LostintravelsdkKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiError")))
@interface LostintravelsdkApollo_apiError : LostintravelsdkBase
- (instancetype)initWithMessage:(NSString *)message locations:(NSArray<LostintravelsdkApollo_apiErrorLocation *> * _Nullable)locations path:(NSArray<id> * _Nullable)path extensions:(NSDictionary<NSString *, id> * _Nullable)extensions nonStandardFields:(NSDictionary<NSString *, id> * _Nullable)nonStandardFields __attribute__((swift_name("init(message:locations:path:extensions:nonStandardFields:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSDictionary<NSString *, id> *customAttributes __attribute__((swift_name("customAttributes"))) __attribute__((unavailable("Used for backward compatibility with 2.x")));
@property (readonly) NSDictionary<NSString *, id> * _Nullable extensions __attribute__((swift_name("extensions")));
@property (readonly) NSArray<LostintravelsdkApollo_apiErrorLocation *> * _Nullable locations __attribute__((swift_name("locations")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) NSDictionary<NSString *, id> * _Nullable nonStandardFields __attribute__((swift_name("nonStandardFields")));
@property (readonly) NSArray<id> * _Nullable path __attribute__((swift_name("path")));
@end

__attribute__((swift_name("Ktor_ioCloseable")))
@protocol LostintravelsdkKtor_ioCloseable
@required
- (void)close __attribute__((swift_name("close_()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClient")))
@interface LostintravelsdkKtor_client_coreHttpClient : LostintravelsdkBase <LostintravelsdkKotlinx_coroutines_coreCoroutineScope, LostintravelsdkKtor_ioCloseable>
- (instancetype)initWithEngine:(id<LostintravelsdkKtor_client_coreHttpClientEngine>)engine userConfig:(LostintravelsdkKtor_client_coreHttpClientConfig<LostintravelsdkKtor_client_coreHttpClientEngineConfig *> *)userConfig __attribute__((swift_name("init(engine:userConfig:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close_()")));
- (LostintravelsdkKtor_client_coreHttpClient *)configBlock:(void (^)(LostintravelsdkKtor_client_coreHttpClientConfig<id> *))block __attribute__((swift_name("config(block:)")));
- (BOOL)isSupportedCapability:(id<LostintravelsdkKtor_client_coreHttpClientEngineCapability>)capability __attribute__((swift_name("isSupported(capability:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<LostintravelsdkKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) id<LostintravelsdkKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<LostintravelsdkKtor_client_coreHttpClientEngine> engine __attribute__((swift_name("engine")));
@property (readonly) LostintravelsdkKtor_client_coreHttpClientEngineConfig *engineConfig __attribute__((swift_name("engineConfig")));
@property (readonly) LostintravelsdkKtor_eventsEvents *monitor __attribute__((swift_name("monitor")));
@property (readonly) LostintravelsdkKtor_client_coreHttpReceivePipeline *receivePipeline __attribute__((swift_name("receivePipeline")));
@property (readonly) LostintravelsdkKtor_client_coreHttpRequestPipeline *requestPipeline __attribute__((swift_name("requestPipeline")));
@property (readonly) LostintravelsdkKtor_client_coreHttpResponsePipeline *responsePipeline __attribute__((swift_name("responsePipeline")));
@property (readonly) LostintravelsdkKtor_client_coreHttpSendPipeline *sendPipeline __attribute__((swift_name("sendPipeline")));
@end

__attribute__((swift_name("Apollo_apiExecutionOptions")))
@protocol LostintravelsdkApollo_apiExecutionOptions
@required
@property (readonly) LostintravelsdkBoolean * _Nullable canBeBatched __attribute__((swift_name("canBeBatched")));
@property (readonly) LostintravelsdkBoolean * _Nullable enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries")));
@property (readonly) id<LostintravelsdkApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) NSArray<LostintravelsdkApollo_apiHttpHeader *> * _Nullable httpHeaders __attribute__((swift_name("httpHeaders")));
@property (readonly) LostintravelsdkApollo_apiHttpMethod * _Nullable httpMethod __attribute__((swift_name("httpMethod")));
@property (readonly) LostintravelsdkBoolean * _Nullable sendApqExtensions __attribute__((swift_name("sendApqExtensions")));
@property (readonly) LostintravelsdkBoolean * _Nullable sendDocument __attribute__((swift_name("sendDocument")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtimeApolloClient")))
@interface LostintravelsdkApollo_runtimeApolloClient : LostintravelsdkBase <LostintravelsdkApollo_apiExecutionOptions>
@property (class, readonly, getter=companion) LostintravelsdkApollo_runtimeApolloClientCompanion *companion __attribute__((swift_name("companion")));
- (void)dispose __attribute__((swift_name("dispose()")));
- (id<LostintravelsdkKotlinx_coroutines_coreFlow>)executeAsFlowApolloRequest:(LostintravelsdkApollo_apiApolloRequest<id<LostintravelsdkApollo_apiOperationData>> *)apolloRequest __attribute__((swift_name("executeAsFlow(apolloRequest:)")));
- (LostintravelsdkApollo_runtimeApolloCall<id<LostintravelsdkApollo_apiMutationData>> *)mutateMutation:(id<LostintravelsdkApollo_apiMutation>)mutation __attribute__((swift_name("mutate(mutation:)"))) __attribute__((deprecated("Used for backward compatibility with 2.x")));
- (LostintravelsdkApollo_runtimeApolloCall<id<LostintravelsdkApollo_apiMutationData>> *)mutationMutation:(id<LostintravelsdkApollo_apiMutation>)mutation __attribute__((swift_name("mutation(mutation:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));
- (void)prefetchOperation:(id<LostintravelsdkApollo_apiOperation>)operation __attribute__((swift_name("prefetch(operation:)"))) __attribute__((unavailable("Use a query and ignore the result")));
- (LostintravelsdkApollo_runtimeApolloCall<id<LostintravelsdkApollo_apiQueryData>> *)queryQuery:(id<LostintravelsdkApollo_apiQuery>)query __attribute__((swift_name("query(query:)")));
- (LostintravelsdkApollo_runtimeApolloCall<id<LostintravelsdkApollo_apiSubscriptionData>> *)subscribeSubscription:(id<LostintravelsdkApollo_apiSubscription>)subscription __attribute__((swift_name("subscribe(subscription:)"))) __attribute__((deprecated("Used for backward compatibility with 2.x")));
- (LostintravelsdkApollo_runtimeApolloCall<id<LostintravelsdkApollo_apiSubscriptionData>> *)subscriptionSubscription:(id<LostintravelsdkApollo_apiSubscription>)subscription __attribute__((swift_name("subscription(subscription:)")));
@property (readonly) LostintravelsdkBoolean * _Nullable canBeBatched __attribute__((swift_name("canBeBatched")));
@property (readonly) LostintravelsdkApollo_apiCustomScalarAdapters *customScalarAdapters __attribute__((swift_name("customScalarAdapters")));
@property (readonly) LostintravelsdkBoolean * _Nullable enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries")));
@property (readonly) id<LostintravelsdkApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) NSArray<LostintravelsdkApollo_apiHttpHeader *> * _Nullable httpHeaders __attribute__((swift_name("httpHeaders")));
@property (readonly) LostintravelsdkApollo_apiHttpMethod * _Nullable httpMethod __attribute__((swift_name("httpMethod")));
@property (readonly) NSArray<id<LostintravelsdkApollo_runtimeApolloInterceptor>> *interceptors __attribute__((swift_name("interceptors")));
@property (readonly) id<LostintravelsdkApollo_runtimeNetworkTransport> networkTransport __attribute__((swift_name("networkTransport")));
@property (readonly) LostintravelsdkBoolean * _Nullable sendApqExtensions __attribute__((swift_name("sendApqExtensions")));
@property (readonly) LostintravelsdkBoolean * _Nullable sendDocument __attribute__((swift_name("sendDocument")));
@property (readonly) id<LostintravelsdkApollo_runtimeNetworkTransport> subscriptionNetworkTransport __attribute__((swift_name("subscriptionNetworkTransport")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol LostintravelsdkKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<LostintravelsdkKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol LostintravelsdkKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<LostintravelsdkKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol LostintravelsdkKotlinx_serialization_coreKSerializer <LostintravelsdkKotlinx_serialization_coreSerializationStrategy, LostintravelsdkKotlinx_serialization_coreDeserializationStrategy>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface LostintravelsdkKotlinArray<T> : LostintravelsdkBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(LostintravelsdkInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<LostintravelsdkKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiExecutableVariables")))
@interface LostintravelsdkApollo_apiExecutableVariables : LostintravelsdkBase
- (instancetype)initWithValueMap:(NSDictionary<NSString *, id> *)valueMap __attribute__((swift_name("init(valueMap:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSDictionary<NSString *, id> *valueMap __attribute__((swift_name("valueMap")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCompiledField.Builder")))
@interface LostintravelsdkApollo_apiCompiledFieldBuilder : LostintravelsdkBase
- (instancetype)initWithCompiledField:(LostintravelsdkApollo_apiCompiledField *)compiledField __attribute__((swift_name("init(compiledField:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithName:(NSString *)name type:(LostintravelsdkApollo_apiCompiledType *)type __attribute__((swift_name("init(name:type:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkApollo_apiCompiledFieldBuilder *)aliasAlias:(NSString * _Nullable)alias __attribute__((swift_name("alias(alias:)")));
- (LostintravelsdkApollo_apiCompiledFieldBuilder *)argumentsArguments:(NSArray<LostintravelsdkApollo_apiCompiledArgument *> *)arguments __attribute__((swift_name("arguments(arguments:)")));
- (LostintravelsdkApollo_apiCompiledField *)build __attribute__((swift_name("build()")));
- (LostintravelsdkApollo_apiCompiledFieldBuilder *)conditionCondition:(NSArray<LostintravelsdkApollo_apiCompiledCondition *> *)condition __attribute__((swift_name("condition(condition:)")));
- (LostintravelsdkApollo_apiCompiledFieldBuilder *)selectionsSelections:(NSArray<LostintravelsdkApollo_apiCompiledSelection *> *)selections __attribute__((swift_name("selections(selections:)")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) LostintravelsdkApollo_apiCompiledType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCompiledArgument")))
@interface LostintravelsdkApollo_apiCompiledArgument : LostintravelsdkBase
- (instancetype)initWithName:(NSString *)name value:(id _Nullable)value isKey:(BOOL)isKey __attribute__((swift_name("init(name:value:isKey:)"))) __attribute__((objc_designated_initializer));
@property (readonly) BOOL isKey __attribute__((swift_name("isKey")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCompiledCondition")))
@interface LostintravelsdkApollo_apiCompiledCondition : LostintravelsdkBase
- (instancetype)initWithName:(NSString *)name inverted:(BOOL)inverted __attribute__((swift_name("init(name:inverted:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkApollo_apiCompiledCondition *)doCopyName:(NSString *)name inverted:(BOOL)inverted __attribute__((swift_name("doCopy(name:inverted:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL inverted __attribute__((swift_name("inverted")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("Apollo_apiUpload")))
@protocol LostintravelsdkApollo_apiUpload
@required
- (void)writeToSink:(id<LostintravelsdkOkioBufferedSink>)sink __attribute__((swift_name("writeTo(sink:)")));
@property (readonly) int64_t contentLength __attribute__((swift_name("contentLength")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@property (readonly) NSString * _Nullable fileName __attribute__((swift_name("fileName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiJsonNumber")))
@interface LostintravelsdkApollo_apiJsonNumber : LostintravelsdkBase
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("Apollo_apiExecutionContextKey")))
@protocol LostintravelsdkApollo_apiExecutionContextKey
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCustomScalarAdapters.Key")))
@interface LostintravelsdkApollo_apiCustomScalarAdaptersKey : LostintravelsdkBase <LostintravelsdkApollo_apiExecutionContextKey>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkApollo_apiCustomScalarAdaptersKey *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkApollo_apiCustomScalarAdapters *Empty __attribute__((swift_name("Empty")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCustomScalarAdapters.Builder")))
@interface LostintravelsdkApollo_apiCustomScalarAdaptersBuilder : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (LostintravelsdkApollo_apiCustomScalarAdaptersBuilder *)addCustomScalarType:(LostintravelsdkApollo_apiCustomScalarType *)customScalarType customScalarAdapter:(id<LostintravelsdkApollo_apiAdapter>)customScalarAdapter __attribute__((swift_name("add(customScalarType:customScalarAdapter:)")));
- (LostintravelsdkApollo_apiCustomScalarAdaptersBuilder *)addCustomScalarType:(LostintravelsdkApollo_apiCustomScalarType *)customScalarType customTypeAdapter:(id<LostintravelsdkApollo_apiCustomTypeAdapter>)customTypeAdapter __attribute__((swift_name("add(customScalarType:customTypeAdapter:)"))) __attribute__((deprecated("Used for backward compatibility with 2.x")));
- (LostintravelsdkApollo_apiCustomScalarAdaptersBuilder *)addAllCustomScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters __attribute__((swift_name("addAll(customScalarAdapters:)")));
- (LostintravelsdkApollo_apiCustomScalarAdapters *)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiHttpRequest.Builder")))
@interface LostintravelsdkApollo_apiHttpRequestBuilder : LostintravelsdkBase
- (instancetype)initWithMethod:(LostintravelsdkApollo_apiHttpMethod *)method url:(NSString *)url __attribute__((swift_name("init(method:url:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkApollo_apiHttpRequestBuilder *)addHeaderName:(NSString *)name value:(NSString *)value __attribute__((swift_name("addHeader(name:value:)")));
- (LostintravelsdkApollo_apiHttpRequestBuilder *)addHeadersHeaders:(NSArray<LostintravelsdkApollo_apiHttpHeader *> *)headers __attribute__((swift_name("addHeaders(headers:)")));
- (LostintravelsdkApollo_apiHttpRequestBuilder *)bodyBody:(id<LostintravelsdkApollo_apiHttpBody>)body __attribute__((swift_name("body(body:)")));
- (LostintravelsdkApollo_apiHttpRequest *)build __attribute__((swift_name("build()")));
- (LostintravelsdkApollo_apiHttpRequestBuilder *)headersHeaders:(NSArray<LostintravelsdkApollo_apiHttpHeader *> *)headers __attribute__((swift_name("headers(headers:)")));
@end

__attribute__((swift_name("Apollo_apiHttpBody")))
@protocol LostintravelsdkApollo_apiHttpBody
@required
- (void)writeToBufferedSink:(id<LostintravelsdkOkioBufferedSink>)bufferedSink __attribute__((swift_name("writeTo(bufferedSink:)")));
@property (readonly) int64_t contentLength __attribute__((swift_name("contentLength")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiHttpHeader")))
@interface LostintravelsdkApollo_apiHttpHeader : LostintravelsdkBase
- (instancetype)initWithName:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol LostintravelsdkKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface LostintravelsdkKotlinEnum<E> : LostintravelsdkBase <LostintravelsdkKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly, getter=name_) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiHttpMethod")))
@interface LostintravelsdkApollo_apiHttpMethod : LostintravelsdkKotlinEnum<LostintravelsdkApollo_apiHttpMethod *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) LostintravelsdkApollo_apiHttpMethod *get __attribute__((swift_name("get")));
@property (class, readonly) LostintravelsdkApollo_apiHttpMethod *post __attribute__((swift_name("post")));
+ (LostintravelsdkKotlinArray<LostintravelsdkApollo_apiHttpMethod *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiHttpResponse.Builder")))
@interface LostintravelsdkApollo_apiHttpResponseBuilder : LostintravelsdkBase
- (instancetype)initWithStatusCode:(int32_t)statusCode __attribute__((swift_name("init(statusCode:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkApollo_apiHttpResponseBuilder *)addHeaderName:(NSString *)name value:(NSString *)value __attribute__((swift_name("addHeader(name:value:)")));
- (LostintravelsdkApollo_apiHttpResponseBuilder *)addHeadersHeaders:(NSArray<LostintravelsdkApollo_apiHttpHeader *> *)headers __attribute__((swift_name("addHeaders(headers:)")));
- (LostintravelsdkApollo_apiHttpResponseBuilder *)bodyBodySource:(id<LostintravelsdkOkioBufferedSource>)bodySource __attribute__((swift_name("body(bodySource:)")));
- (LostintravelsdkApollo_apiHttpResponseBuilder *)bodyBodyString:(LostintravelsdkOkioByteString *)bodyString __attribute__((swift_name("body(bodyString:)")));
- (LostintravelsdkApollo_apiHttpResponse *)build __attribute__((swift_name("build()")));
- (LostintravelsdkApollo_apiHttpResponseBuilder *)headersHeaders:(NSArray<LostintravelsdkApollo_apiHttpHeader *> *)headers __attribute__((swift_name("headers(headers:)")));
@property (readonly) int32_t statusCode __attribute__((swift_name("statusCode")));
@end

__attribute__((swift_name("OkioSource")))
@protocol LostintravelsdkOkioSource <LostintravelsdkOkioCloseable>
@required

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (int64_t)readSink:(LostintravelsdkOkioBuffer *)sink byteCount:(int64_t)byteCount error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("read(sink:byteCount:)"))) __attribute__((swift_error(nonnull_error)));
- (LostintravelsdkOkioTimeout *)timeout __attribute__((swift_name("timeout()")));
@end

__attribute__((swift_name("OkioBufferedSource")))
@protocol LostintravelsdkOkioBufferedSource <LostintravelsdkOkioSource>
@required
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (int64_t)indexOfB:(int8_t)b __attribute__((swift_name("indexOf(b:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(b:fromIndex:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex toIndex:(int64_t)toIndex __attribute__((swift_name("indexOf(b:fromIndex:toIndex:)")));
- (int64_t)indexOfBytes:(LostintravelsdkOkioByteString *)bytes __attribute__((swift_name("indexOf(bytes:)")));
- (int64_t)indexOfBytes:(LostintravelsdkOkioByteString *)bytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(bytes:fromIndex:)")));
- (int64_t)indexOfElementTargetBytes:(LostintravelsdkOkioByteString *)targetBytes __attribute__((swift_name("indexOfElement(targetBytes:)")));
- (int64_t)indexOfElementTargetBytes:(LostintravelsdkOkioByteString *)targetBytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOfElement(targetBytes:fromIndex:)")));
- (id<LostintravelsdkOkioBufferedSource>)peek __attribute__((swift_name("peek_()")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(LostintravelsdkOkioByteString *)bytes __attribute__((swift_name("rangeEquals(offset:bytes:)")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(LostintravelsdkOkioByteString *)bytes bytesOffset:(int32_t)bytesOffset byteCount:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:bytes:bytesOffset:byteCount:)")));
- (int32_t)readSink:(LostintravelsdkKotlinByteArray *)sink __attribute__((swift_name("read(sink:)")));
- (int32_t)readSink:(LostintravelsdkKotlinByteArray *)sink offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("read(sink:offset:byteCount:)")));
- (int64_t)readAllSink:(id<LostintravelsdkOkioSink>)sink __attribute__((swift_name("readAll(sink:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (LostintravelsdkKotlinByteArray *)readByteArray __attribute__((swift_name("readByteArray()")));
- (LostintravelsdkKotlinByteArray *)readByteArrayByteCount:(int64_t)byteCount __attribute__((swift_name("readByteArray(byteCount:)")));
- (LostintravelsdkOkioByteString *)readByteString __attribute__((swift_name("readByteString()")));
- (LostintravelsdkOkioByteString *)readByteStringByteCount:(int64_t)byteCount __attribute__((swift_name("readByteString(byteCount:)")));
- (int64_t)readDecimalLong __attribute__((swift_name("readDecimalLong()")));
- (void)readFullySink:(LostintravelsdkKotlinByteArray *)sink __attribute__((swift_name("readFully(sink:)")));
- (void)readFullySink:(LostintravelsdkOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readFully(sink:byteCount:)")));
- (int64_t)readHexadecimalUnsignedLong __attribute__((swift_name("readHexadecimalUnsignedLong()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int32_t)readIntLe __attribute__((swift_name("readIntLe()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int64_t)readLongLe __attribute__((swift_name("readLongLe()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (int16_t)readShortLe __attribute__((swift_name("readShortLe()")));
- (NSString *)readUtf8 __attribute__((swift_name("readUtf8()")));
- (NSString *)readUtf8ByteCount:(int64_t)byteCount __attribute__((swift_name("readUtf8(byteCount:)")));
- (int32_t)readUtf8CodePoint __attribute__((swift_name("readUtf8CodePoint()")));
- (NSString * _Nullable)readUtf8Line __attribute__((swift_name("readUtf8Line()")));
- (NSString *)readUtf8LineStrict __attribute__((swift_name("readUtf8LineStrict()")));
- (NSString *)readUtf8LineStrictLimit:(int64_t)limit __attribute__((swift_name("readUtf8LineStrict(limit:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (int32_t)selectOptions:(NSArray<LostintravelsdkOkioByteString *> *)options __attribute__((swift_name("select(options:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
@property (readonly) LostintravelsdkOkioBuffer *buffer __attribute__((swift_name("buffer")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiOptionalCompanion")))
@interface LostintravelsdkApollo_apiOptionalCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkApollo_apiOptionalCompanion *shared __attribute__((swift_name("shared")));
- (LostintravelsdkApollo_apiOptional<id> *)presentIfNotNullValue:(id _Nullable)value __attribute__((swift_name("presentIfNotNull(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiInterfaceType")))
@interface LostintravelsdkApollo_apiInterfaceType : LostintravelsdkApollo_apiCompiledNamedType
- (instancetype)initWithName:(NSString *)name keyFields:(NSArray<NSString *> *)keyFields implements:(NSArray<LostintravelsdkApollo_apiInterfaceType *> *)implements __attribute__((swift_name("init(name:keyFields:implements:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSArray<LostintravelsdkApollo_apiInterfaceType *> *implements __attribute__((swift_name("implements")));
@property (readonly) NSArray<NSString *> *keyFields __attribute__((swift_name("keyFields")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface LostintravelsdkKotlinNothing : LostintravelsdkBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiJsonReaderToken")))
@interface LostintravelsdkApollo_apiJsonReaderToken : LostintravelsdkKotlinEnum<LostintravelsdkApollo_apiJsonReaderToken *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) LostintravelsdkApollo_apiJsonReaderToken *beginArray __attribute__((swift_name("beginArray")));
@property (class, readonly) LostintravelsdkApollo_apiJsonReaderToken *endArray __attribute__((swift_name("endArray")));
@property (class, readonly) LostintravelsdkApollo_apiJsonReaderToken *beginObject __attribute__((swift_name("beginObject")));
@property (class, readonly) LostintravelsdkApollo_apiJsonReaderToken *endObject __attribute__((swift_name("endObject")));
@property (class, readonly) LostintravelsdkApollo_apiJsonReaderToken *name __attribute__((swift_name("name")));
@property (class, readonly) LostintravelsdkApollo_apiJsonReaderToken *string __attribute__((swift_name("string")));
@property (class, readonly) LostintravelsdkApollo_apiJsonReaderToken *number __attribute__((swift_name("number")));
@property (class, readonly) LostintravelsdkApollo_apiJsonReaderToken *long_ __attribute__((swift_name("long_")));
@property (class, readonly) LostintravelsdkApollo_apiJsonReaderToken *boolean __attribute__((swift_name("boolean")));
@property (class, readonly) LostintravelsdkApollo_apiJsonReaderToken *null __attribute__((swift_name("null")));
@property (class, readonly) LostintravelsdkApollo_apiJsonReaderToken *endDocument __attribute__((swift_name("endDocument")));
+ (LostintravelsdkKotlinArray<LostintravelsdkApollo_apiJsonReaderToken *> *)values __attribute__((swift_name("values()")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinCoroutineContext")))
@protocol LostintravelsdkKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation_:(id _Nullable (^)(id _Nullable, id<LostintravelsdkKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation_:)")));
- (id<LostintravelsdkKotlinCoroutineContextElement> _Nullable)getKey_:(id<LostintravelsdkKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key_:)")));
- (id<LostintravelsdkKotlinCoroutineContext>)minusKeyKey_:(id<LostintravelsdkKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key_:)")));
- (id<LostintravelsdkKotlinCoroutineContext>)plusContext_:(id<LostintravelsdkKotlinCoroutineContext>)context __attribute__((swift_name("plus(context_:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiError.Location")))
@interface LostintravelsdkApollo_apiErrorLocation : LostintravelsdkBase
- (instancetype)initWithLine:(int32_t)line column:(int32_t)column __attribute__((swift_name("init(line:column:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t column __attribute__((swift_name("column")));
@property (readonly) int32_t line __attribute__((swift_name("line")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientEngine")))
@protocol LostintravelsdkKtor_client_coreHttpClientEngine <LostintravelsdkKotlinx_coroutines_coreCoroutineScope, LostintravelsdkKtor_ioCloseable>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeData:(LostintravelsdkKtor_client_coreHttpRequestData *)data completionHandler:(void (^)(LostintravelsdkKtor_client_coreHttpResponseData * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(data:completionHandler:)")));
- (void)installClient:(LostintravelsdkKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
@property (readonly) LostintravelsdkKtor_client_coreHttpClientEngineConfig *config __attribute__((swift_name("config")));
@property (readonly) LostintravelsdkKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher")));
@property (readonly) NSSet<id<LostintravelsdkKtor_client_coreHttpClientEngineCapability>> *supportedCapabilities __attribute__((swift_name("supportedCapabilities")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientEngineConfig")))
@interface LostintravelsdkKtor_client_coreHttpClientEngineConfig : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property BOOL pipelining __attribute__((swift_name("pipelining")));
@property LostintravelsdkKtor_client_coreProxyConfig * _Nullable proxy __attribute__((swift_name("proxy")));
@property int32_t threadsCount __attribute__((swift_name("threadsCount")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientConfig")))
@interface LostintravelsdkKtor_client_coreHttpClientConfig<T> : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (LostintravelsdkKtor_client_coreHttpClientConfig<T> *)clone __attribute__((swift_name("clone()")));
- (void)engineBlock:(void (^)(T))block __attribute__((swift_name("engine(block:)")));
- (void)installClient:(LostintravelsdkKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
- (void)installPlugin:(id<LostintravelsdkKtor_client_coreHttpClientPlugin>)plugin configure:(void (^)(id))configure __attribute__((swift_name("install(plugin:configure:)")));
- (void)installKey:(NSString *)key block:(void (^)(LostintravelsdkKtor_client_coreHttpClient *))block __attribute__((swift_name("install(key:block:)")));
- (void)plusAssignOther:(LostintravelsdkKtor_client_coreHttpClientConfig<T> *)other __attribute__((swift_name("plusAssign(other:)")));
@property BOOL developmentMode __attribute__((swift_name("developmentMode")));
@property BOOL expectSuccess __attribute__((swift_name("expectSuccess")));
@property BOOL followRedirects __attribute__((swift_name("followRedirects")));
@property BOOL useDefaultTransformers __attribute__((swift_name("useDefaultTransformers")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientEngineCapability")))
@protocol LostintravelsdkKtor_client_coreHttpClientEngineCapability
@required
@end

__attribute__((swift_name("Ktor_utilsAttributes")))
@protocol LostintravelsdkKtor_utilsAttributes
@required
- (id)computeIfAbsentKey:(LostintravelsdkKtor_utilsAttributeKey<id> *)key block:(id (^)(void))block __attribute__((swift_name("computeIfAbsent(key:block:)")));
- (BOOL)containsKey:(LostintravelsdkKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("contains(key:)")));
- (id)getKey__:(LostintravelsdkKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("get(key__:)")));
- (id _Nullable)getOrNullKey:(LostintravelsdkKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getOrNull(key:)")));
- (void)putKey:(LostintravelsdkKtor_utilsAttributeKey<id> *)key value:(id)value __attribute__((swift_name("put(key:value:)")));
- (void)removeKey:(LostintravelsdkKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("remove(key:)")));
- (id)takeKey:(LostintravelsdkKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("take(key:)")));
- (id _Nullable)takeOrNullKey:(LostintravelsdkKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("takeOrNull(key:)")));
@property (readonly) NSArray<LostintravelsdkKtor_utilsAttributeKey<id> *> *allKeys __attribute__((swift_name("allKeys")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_eventsEvents")))
@interface LostintravelsdkKtor_eventsEvents : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)raiseDefinition:(LostintravelsdkKtor_eventsEventDefinition<id> *)definition value:(id _Nullable)value __attribute__((swift_name("raise(definition:value:)")));
- (id<LostintravelsdkKotlinx_coroutines_coreDisposableHandle>)subscribeDefinition:(LostintravelsdkKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("subscribe(definition:handler:)")));
- (void)unsubscribeDefinition:(LostintravelsdkKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("unsubscribe(definition:handler:)")));
@end

__attribute__((swift_name("Ktor_utilsPipeline")))
@interface LostintravelsdkKtor_utilsPipeline<TSubject, TContext> : LostintravelsdkBase
- (instancetype)initWithPhase:(LostintravelsdkKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<LostintravelsdkKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(LostintravelsdkKotlinArray<LostintravelsdkKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer));
- (void)addPhasePhase:(LostintravelsdkKtor_utilsPipelinePhase *)phase __attribute__((swift_name("addPhase(phase:)")));
- (void)afterIntercepted __attribute__((swift_name("afterIntercepted()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeContext:(TContext)context subject:(TSubject)subject completionHandler:(void (^)(TSubject _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(context:subject:completionHandler:)")));
- (void)insertPhaseAfterReference:(LostintravelsdkKtor_utilsPipelinePhase *)reference phase:(LostintravelsdkKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseAfter(reference:phase:)")));
- (void)insertPhaseBeforeReference:(LostintravelsdkKtor_utilsPipelinePhase *)reference phase:(LostintravelsdkKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseBefore(reference:phase:)")));
- (void)interceptPhase:(LostintravelsdkKtor_utilsPipelinePhase *)phase block:(id<LostintravelsdkKotlinSuspendFunction2>)block __attribute__((swift_name("intercept(phase:block:)")));
- (NSArray<id<LostintravelsdkKotlinSuspendFunction2>> *)interceptorsForPhasePhase:(LostintravelsdkKtor_utilsPipelinePhase *)phase __attribute__((swift_name("interceptorsForPhase(phase:)")));
- (void)mergeFrom:(LostintravelsdkKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("merge(from:)")));
- (void)mergePhasesFrom:(LostintravelsdkKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("mergePhases(from:)")));
- (void)resetFromFrom:(LostintravelsdkKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("resetFrom(from:)")));
@property (readonly) id<LostintravelsdkKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@property (readonly) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) NSArray<LostintravelsdkKtor_utilsPipelinePhase *> *items __attribute__((swift_name("items")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline")))
@interface LostintravelsdkKtor_client_coreHttpReceivePipeline : LostintravelsdkKtor_utilsPipeline<LostintravelsdkKtor_client_coreHttpResponse *, LostintravelsdkKotlinUnit *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(LostintravelsdkKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<LostintravelsdkKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(LostintravelsdkKotlinArray<LostintravelsdkKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) LostintravelsdkKtor_client_coreHttpReceivePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline")))
@interface LostintravelsdkKtor_client_coreHttpRequestPipeline : LostintravelsdkKtor_utilsPipeline<id, LostintravelsdkKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(LostintravelsdkKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<LostintravelsdkKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(LostintravelsdkKotlinArray<LostintravelsdkKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) LostintravelsdkKtor_client_coreHttpRequestPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline")))
@interface LostintravelsdkKtor_client_coreHttpResponsePipeline : LostintravelsdkKtor_utilsPipeline<LostintravelsdkKtor_client_coreHttpResponseContainer *, LostintravelsdkKtor_client_coreHttpClientCall *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(LostintravelsdkKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<LostintravelsdkKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(LostintravelsdkKotlinArray<LostintravelsdkKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) LostintravelsdkKtor_client_coreHttpResponsePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline")))
@interface LostintravelsdkKtor_client_coreHttpSendPipeline : LostintravelsdkKtor_utilsPipeline<id, LostintravelsdkKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(LostintravelsdkKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<LostintravelsdkKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(LostintravelsdkKotlinArray<LostintravelsdkKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) LostintravelsdkKtor_client_coreHttpSendPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtimeApolloClient.Companion")))
@interface LostintravelsdkApollo_runtimeApolloClientCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkApollo_runtimeApolloClientCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)builder __attribute__((swift_name("builder()"))) __attribute__((deprecated("Used for backward compatibility with 2.x")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiApolloRequest")))
@interface LostintravelsdkApollo_apiApolloRequest<D> : LostintravelsdkBase <LostintravelsdkApollo_apiExecutionOptions>
- (LostintravelsdkApollo_apiApolloRequestBuilder<D> *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));
@property (readonly) LostintravelsdkBoolean * _Nullable canBeBatched __attribute__((swift_name("canBeBatched")));
@property (readonly) LostintravelsdkBoolean * _Nullable enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries")));
@property (readonly) id<LostintravelsdkApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) NSArray<LostintravelsdkApollo_apiHttpHeader *> * _Nullable httpHeaders __attribute__((swift_name("httpHeaders")));
@property (readonly) LostintravelsdkApollo_apiHttpMethod * _Nullable httpMethod __attribute__((swift_name("httpMethod")));
@property (readonly) id<LostintravelsdkApollo_apiOperation> operation __attribute__((swift_name("operation")));
@property (readonly) LostintravelsdkUuidUuid *requestUuid __attribute__((swift_name("requestUuid")));
@property (readonly) LostintravelsdkBoolean * _Nullable sendApqExtensions __attribute__((swift_name("sendApqExtensions")));
@property (readonly) LostintravelsdkBoolean * _Nullable sendDocument __attribute__((swift_name("sendDocument")));
@end

__attribute__((swift_name("Apollo_apiMutableExecutionOptions")))
@protocol LostintravelsdkApollo_apiMutableExecutionOptions <LostintravelsdkApollo_apiExecutionOptions>
@required
- (id _Nullable)addExecutionContextExecutionContext:(id<LostintravelsdkApollo_apiExecutionContext>)executionContext __attribute__((swift_name("addExecutionContext(executionContext:)")));
- (id _Nullable)addHttpHeaderName:(NSString *)name value:(NSString *)value __attribute__((swift_name("addHttpHeader(name:value:)")));
- (id _Nullable)canBeBatchedCanBeBatched:(LostintravelsdkBoolean * _Nullable)canBeBatched __attribute__((swift_name("canBeBatched(canBeBatched:)")));
- (id _Nullable)enableAutoPersistedQueriesEnableAutoPersistedQueries:(LostintravelsdkBoolean * _Nullable)enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries(enableAutoPersistedQueries:)")));
- (id _Nullable)httpHeadersHttpHeaders:(NSArray<LostintravelsdkApollo_apiHttpHeader *> * _Nullable)httpHeaders __attribute__((swift_name("httpHeaders(httpHeaders:)")));
- (id _Nullable)httpMethodHttpMethod:(LostintravelsdkApollo_apiHttpMethod * _Nullable)httpMethod __attribute__((swift_name("httpMethod(httpMethod:)")));
- (id _Nullable)sendApqExtensionsSendApqExtensions:(LostintravelsdkBoolean * _Nullable)sendApqExtensions __attribute__((swift_name("sendApqExtensions(sendApqExtensions:)")));
- (id _Nullable)sendDocumentSendDocument:(LostintravelsdkBoolean * _Nullable)sendDocument __attribute__((swift_name("sendDocument(sendDocument:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtimeApolloCall")))
@interface LostintravelsdkApollo_runtimeApolloCall<D> : LostintravelsdkBase <LostintravelsdkApollo_apiMutableExecutionOptions>
- (LostintravelsdkApollo_runtimeApolloCall<D> *)addExecutionContextExecutionContext:(id<LostintravelsdkApollo_apiExecutionContext>)executionContext __attribute__((swift_name("addExecutionContext(executionContext:)")));
- (LostintravelsdkApollo_runtimeApolloCall<D> *)addHttpHeaderName:(NSString *)name value:(NSString *)value __attribute__((swift_name("addHttpHeader(name:value:)")));
- (LostintravelsdkApollo_runtimeApolloCall<D> *)canBeBatchedCanBeBatched:(LostintravelsdkBoolean * _Nullable)canBeBatched __attribute__((swift_name("canBeBatched(canBeBatched:)")));
- (LostintravelsdkApollo_runtimeApolloCall<D> *)doCopy __attribute__((swift_name("doCopy()")));
- (LostintravelsdkApollo_runtimeApolloCall<D> *)enableAutoPersistedQueriesEnableAutoPersistedQueries:(LostintravelsdkBoolean * _Nullable)enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries(enableAutoPersistedQueries:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeWithCompletionHandler:(void (^)(LostintravelsdkApollo_apiApolloResponse<D> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(completionHandler:)")));
- (LostintravelsdkApollo_runtimeApolloCall<D> *)httpHeadersHttpHeaders:(NSArray<LostintravelsdkApollo_apiHttpHeader *> * _Nullable)httpHeaders __attribute__((swift_name("httpHeaders(httpHeaders:)")));
- (LostintravelsdkApollo_runtimeApolloCall<D> *)httpMethodHttpMethod:(LostintravelsdkApollo_apiHttpMethod * _Nullable)httpMethod __attribute__((swift_name("httpMethod(httpMethod:)")));
- (LostintravelsdkApollo_runtimeApolloCall<D> *)sendApqExtensionsSendApqExtensions:(LostintravelsdkBoolean * _Nullable)sendApqExtensions __attribute__((swift_name("sendApqExtensions(sendApqExtensions:)")));
- (LostintravelsdkApollo_runtimeApolloCall<D> *)sendDocumentSendDocument:(LostintravelsdkBoolean * _Nullable)sendDocument __attribute__((swift_name("sendDocument(sendDocument:)")));
- (id<LostintravelsdkKotlinx_coroutines_coreFlow>)toFlow __attribute__((swift_name("toFlow()")));
@property LostintravelsdkBoolean * _Nullable canBeBatched __attribute__((swift_name("canBeBatched")));
@property LostintravelsdkBoolean * _Nullable enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries")));
@property id<LostintravelsdkApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property NSArray<LostintravelsdkApollo_apiHttpHeader *> * _Nullable httpHeaders __attribute__((swift_name("httpHeaders")));
@property LostintravelsdkApollo_apiHttpMethod * _Nullable httpMethod __attribute__((swift_name("httpMethod")));
@property (readonly) id<LostintravelsdkApollo_apiOperation> operation __attribute__((swift_name("operation")));
@property LostintravelsdkBoolean * _Nullable sendApqExtensions __attribute__((swift_name("sendApqExtensions")));
@property LostintravelsdkBoolean * _Nullable sendDocument __attribute__((swift_name("sendDocument")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtimeApolloClient.Builder")))
@interface LostintravelsdkApollo_runtimeApolloClientBuilder : LostintravelsdkBase <LostintravelsdkApollo_apiMutableExecutionOptions>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)addCustomScalarAdapterCustomScalarType:(LostintravelsdkApollo_apiCustomScalarType *)customScalarType customScalarAdapter:(id<LostintravelsdkApollo_apiAdapter>)customScalarAdapter __attribute__((swift_name("addCustomScalarAdapter(customScalarType:customScalarAdapter:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)addCustomTypeAdapterCustomScalarType:(LostintravelsdkApollo_apiCustomScalarType *)customScalarType customTypeAdapter:(id<LostintravelsdkApollo_apiCustomTypeAdapter>)customTypeAdapter __attribute__((swift_name("addCustomTypeAdapter(customScalarType:customTypeAdapter:)"))) __attribute__((deprecated("Used for backward compatibility with 2.x")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)addExecutionContextExecutionContext:(id<LostintravelsdkApollo_apiExecutionContext>)executionContext __attribute__((swift_name("addExecutionContext(executionContext:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)addHttpHeaderName:(NSString *)name value:(NSString *)value __attribute__((swift_name("addHttpHeader(name:value:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)addHttpInterceptorHttpInterceptor:(id<LostintravelsdkApollo_runtimeHttpInterceptor>)httpInterceptor __attribute__((swift_name("addHttpInterceptor(httpInterceptor:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)addInterceptorInterceptor:(id<LostintravelsdkApollo_runtimeApolloInterceptor>)interceptor __attribute__((swift_name("addInterceptor(interceptor:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)addInterceptorsInterceptors:(NSArray<id<LostintravelsdkApollo_runtimeApolloInterceptor>> *)interceptors __attribute__((swift_name("addInterceptors(interceptors:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)autoPersistedQueriesHttpMethodForHashedQueries:(LostintravelsdkApollo_apiHttpMethod *)httpMethodForHashedQueries httpMethodForDocumentQueries:(LostintravelsdkApollo_apiHttpMethod *)httpMethodForDocumentQueries enableByDefault:(BOOL)enableByDefault __attribute__((swift_name("autoPersistedQueries(httpMethodForHashedQueries:httpMethodForDocumentQueries:enableByDefault:)")));
- (LostintravelsdkApollo_runtimeApolloClient *)build __attribute__((swift_name("build()")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)canBeBatchedCanBeBatched:(LostintravelsdkBoolean * _Nullable)canBeBatched __attribute__((swift_name("canBeBatched(canBeBatched:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)customScalarAdaptersCustomScalarAdapters:(LostintravelsdkApollo_apiCustomScalarAdapters *)customScalarAdapters __attribute__((swift_name("customScalarAdapters(customScalarAdapters:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)enableAutoPersistedQueriesEnableAutoPersistedQueries:(LostintravelsdkBoolean * _Nullable)enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries(enableAutoPersistedQueries:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)executionContextExecutionContext:(id<LostintravelsdkApollo_apiExecutionContext>)executionContext __attribute__((swift_name("executionContext(executionContext:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)httpBatchingBatchIntervalMillis:(int64_t)batchIntervalMillis maxBatchSize:(int32_t)maxBatchSize enableByDefault:(BOOL)enableByDefault __attribute__((swift_name("httpBatching(batchIntervalMillis:maxBatchSize:enableByDefault:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)httpEngineHttpEngine:(id<LostintravelsdkApollo_runtimeHttpEngine>)httpEngine __attribute__((swift_name("httpEngine(httpEngine:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)httpExposeErrorBodyHttpExposeErrorBody:(BOOL)httpExposeErrorBody __attribute__((swift_name("httpExposeErrorBody(httpExposeErrorBody:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)httpHeadersHttpHeaders:(NSArray<LostintravelsdkApollo_apiHttpHeader *> * _Nullable)httpHeaders __attribute__((swift_name("httpHeaders(httpHeaders:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)httpMethodHttpMethod:(LostintravelsdkApollo_apiHttpMethod * _Nullable)httpMethod __attribute__((swift_name("httpMethod(httpMethod:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)httpServerUrlHttpServerUrl:(NSString *)httpServerUrl __attribute__((swift_name("httpServerUrl(httpServerUrl:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)interceptorsInterceptors:(NSArray<id<LostintravelsdkApollo_runtimeApolloInterceptor>> *)interceptors __attribute__((swift_name("interceptors(interceptors:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)networkTransportNetworkTransport:(id<LostintravelsdkApollo_runtimeNetworkTransport>)networkTransport __attribute__((swift_name("networkTransport(networkTransport:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)requestedDispatcherRequestedDispatcher:(LostintravelsdkKotlinx_coroutines_coreCoroutineDispatcher * _Nullable)requestedDispatcher __attribute__((swift_name("requestedDispatcher(requestedDispatcher:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)sendApqExtensionsSendApqExtensions:(LostintravelsdkBoolean * _Nullable)sendApqExtensions __attribute__((swift_name("sendApqExtensions(sendApqExtensions:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)sendDocumentSendDocument:(LostintravelsdkBoolean * _Nullable)sendDocument __attribute__((swift_name("sendDocument(sendDocument:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)serverUrlServerUrl:(NSString *)serverUrl __attribute__((swift_name("serverUrl(serverUrl:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)subscriptionNetworkTransportSubscriptionNetworkTransport:(id<LostintravelsdkApollo_runtimeNetworkTransport>)subscriptionNetworkTransport __attribute__((swift_name("subscriptionNetworkTransport(subscriptionNetworkTransport:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)useHttpGetMethodForPersistedQueriesUseHttpGetMethodForQueries:(BOOL)useHttpGetMethodForQueries __attribute__((swift_name("useHttpGetMethodForPersistedQueries(useHttpGetMethodForQueries:)"))) __attribute__((deprecated("Used for backward compatibility with 2.x. This method throws immediately")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)useHttpGetMethodForQueriesUseHttpGetMethodForQueries:(BOOL)useHttpGetMethodForQueries __attribute__((swift_name("useHttpGetMethodForQueries(useHttpGetMethodForQueries:)"))) __attribute__((deprecated("Used for backward compatibility with 2.x")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)webSocketEngineWebSocketEngine:(id<LostintravelsdkApollo_runtimeWebSocketEngine>)webSocketEngine __attribute__((swift_name("webSocketEngine(webSocketEngine:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)webSocketIdleTimeoutMillisWebSocketIdleTimeoutMillis:(int64_t)webSocketIdleTimeoutMillis __attribute__((swift_name("webSocketIdleTimeoutMillis(webSocketIdleTimeoutMillis:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)webSocketReconnectWhenWebSocketReconnectWhen:(LostintravelsdkBoolean *(^)(LostintravelsdkKotlinThrowable *))webSocketReconnectWhen __attribute__((swift_name("webSocketReconnectWhen(webSocketReconnectWhen:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)webSocketServerUrlWebSocketServerUrl:(NSString *)webSocketServerUrl __attribute__((swift_name("webSocketServerUrl(webSocketServerUrl:)")));
- (LostintravelsdkApollo_runtimeApolloClientBuilder *)wsProtocolWsProtocolFactory:(id<LostintravelsdkApollo_runtimeWsProtocolFactory>)wsProtocolFactory __attribute__((swift_name("wsProtocol(wsProtocolFactory:)")));
@property LostintravelsdkBoolean * _Nullable canBeBatched __attribute__((swift_name("canBeBatched")));
@property LostintravelsdkBoolean * _Nullable enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries")));
@property id<LostintravelsdkApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property NSArray<LostintravelsdkApollo_apiHttpHeader *> * _Nullable httpHeaders __attribute__((swift_name("httpHeaders")));
@property LostintravelsdkApollo_apiHttpMethod * _Nullable httpMethod __attribute__((swift_name("httpMethod")));
@property (readonly) NSArray<id<LostintravelsdkApollo_runtimeApolloInterceptor>> *interceptors __attribute__((swift_name("interceptors")));
@property LostintravelsdkBoolean * _Nullable sendApqExtensions __attribute__((swift_name("sendApqExtensions")));
@property LostintravelsdkBoolean * _Nullable sendDocument __attribute__((swift_name("sendDocument")));
@end

__attribute__((swift_name("Apollo_apiQueryData")))
@protocol LostintravelsdkApollo_apiQueryData <LostintravelsdkApollo_apiOperationData>
@required
@end

__attribute__((swift_name("Apollo_apiQuery")))
@protocol LostintravelsdkApollo_apiQuery <LostintravelsdkApollo_apiOperation>
@required
@end

__attribute__((swift_name("Apollo_apiSubscriptionData")))
@protocol LostintravelsdkApollo_apiSubscriptionData <LostintravelsdkApollo_apiOperationData>
@required
@end

__attribute__((swift_name("Apollo_apiSubscription")))
@protocol LostintravelsdkApollo_apiSubscription <LostintravelsdkApollo_apiOperation>
@required
@end

__attribute__((swift_name("Apollo_runtimeApolloInterceptor")))
@protocol LostintravelsdkApollo_runtimeApolloInterceptor
@required
- (id<LostintravelsdkKotlinx_coroutines_coreFlow>)interceptRequest:(LostintravelsdkApollo_apiApolloRequest<id<LostintravelsdkApollo_apiOperationData>> *)request chain:(id<LostintravelsdkApollo_runtimeApolloInterceptorChain>)chain __attribute__((swift_name("intercept(request:chain:)")));
@end

__attribute__((swift_name("Apollo_runtimeNetworkTransport")))
@protocol LostintravelsdkApollo_runtimeNetworkTransport
@required
- (void)dispose __attribute__((swift_name("dispose()")));
- (id<LostintravelsdkKotlinx_coroutines_coreFlow>)executeRequest:(LostintravelsdkApollo_apiApolloRequest<id<LostintravelsdkApollo_apiOperationData>> *)request __attribute__((swift_name("execute(request:)")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol LostintravelsdkKotlinx_serialization_coreEncoder
@required
- (id<LostintravelsdkKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<LostintravelsdkKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<LostintravelsdkKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<LostintravelsdkKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<LostintravelsdkKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) LostintravelsdkKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol LostintravelsdkKotlinx_serialization_coreSerialDescriptor
@required

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSArray<id<LostintravelsdkKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSArray<id<LostintravelsdkKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) LostintravelsdkKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol LostintravelsdkKotlinx_serialization_coreDecoder
@required
- (id<LostintravelsdkKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<LostintravelsdkKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (LostintravelsdkKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<LostintravelsdkKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<LostintravelsdkKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) LostintravelsdkKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol LostintravelsdkKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext_()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("OkioSink")))
@protocol LostintravelsdkOkioSink <LostintravelsdkOkioCloseable>
@required

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)flushAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("flush()")));
- (LostintravelsdkOkioTimeout *)timeout __attribute__((swift_name("timeout()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)writeSource:(LostintravelsdkOkioBuffer *)source byteCount:(int64_t)byteCount error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("write(source:byteCount_:)")));
@end

__attribute__((swift_name("OkioBufferedSink")))
@protocol LostintravelsdkOkioBufferedSink <LostintravelsdkOkioSink>
@required
- (id<LostintravelsdkOkioBufferedSink>)emit __attribute__((swift_name("emit()")));
- (id<LostintravelsdkOkioBufferedSink>)emitCompleteSegments __attribute__((swift_name("emitCompleteSegments()")));
- (id<LostintravelsdkOkioBufferedSink>)writeSource:(LostintravelsdkKotlinByteArray *)source __attribute__((swift_name("write(source:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeSource:(LostintravelsdkKotlinByteArray *)source offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(source:offset:byteCount:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeByteString:(LostintravelsdkOkioByteString *)byteString __attribute__((swift_name("write(byteString:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeByteString:(LostintravelsdkOkioByteString *)byteString offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(byteString:offset:byteCount:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeSource:(id<LostintravelsdkOkioSource>)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
- (int64_t)writeAllSource:(id<LostintravelsdkOkioSource>)source __attribute__((swift_name("writeAll(source:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeByteB:(int32_t)b __attribute__((swift_name("writeByte(b:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeDecimalLongV:(int64_t)v __attribute__((swift_name("writeDecimalLong(v:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeHexadecimalUnsignedLongV:(int64_t)v __attribute__((swift_name("writeHexadecimalUnsignedLong(v:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeIntI:(int32_t)i __attribute__((swift_name("writeInt(i:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeIntLeI:(int32_t)i __attribute__((swift_name("writeIntLe(i:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeLongV:(int64_t)v __attribute__((swift_name("writeLong(v:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeLongLeV:(int64_t)v __attribute__((swift_name("writeLongLe(v:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeShortS:(int32_t)s __attribute__((swift_name("writeShort(s:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeShortLeS:(int32_t)s __attribute__((swift_name("writeShortLe(s:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeUtf8String:(NSString *)string __attribute__((swift_name("writeUtf8(string:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeUtf8String:(NSString *)string beginIndex:(int32_t)beginIndex endIndex:(int32_t)endIndex __attribute__((swift_name("writeUtf8(string:beginIndex:endIndex:)")));
- (id<LostintravelsdkOkioBufferedSink>)writeUtf8CodePointCodePoint:(int32_t)codePoint __attribute__((swift_name("writeUtf8CodePoint(codePoint:)")));
@property (readonly) LostintravelsdkOkioBuffer *buffer __attribute__((swift_name("buffer")));
@end

__attribute__((swift_name("Apollo_apiCustomTypeAdapter")))
@protocol LostintravelsdkApollo_apiCustomTypeAdapter
@required
- (id _Nullable)decodeValue:(LostintravelsdkApollo_apiCustomTypeValue<id> *)value __attribute__((swift_name("decode(value:)")));
- (LostintravelsdkApollo_apiCustomTypeValue<id> *)encodeValue:(id _Nullable)value __attribute__((swift_name("encode(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface LostintravelsdkKotlinEnumCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("OkioByteString")))
@interface LostintravelsdkOkioByteString : LostintravelsdkBase <LostintravelsdkKotlinComparable>
@property (class, readonly, getter=companion) LostintravelsdkOkioByteStringCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)base64 __attribute__((swift_name("base64()")));
- (NSString *)base64Url __attribute__((swift_name("base64Url()")));
- (int32_t)compareToOther:(LostintravelsdkOkioByteString *)other __attribute__((swift_name("compareTo(other:)")));
- (void)doCopyIntoOffset:(int32_t)offset target:(LostintravelsdkKotlinByteArray *)target targetOffset:(int32_t)targetOffset byteCount:(int32_t)byteCount __attribute__((swift_name("doCopyInto(offset:target:targetOffset:byteCount:)")));
- (BOOL)endsWithSuffix:(LostintravelsdkKotlinByteArray *)suffix __attribute__((swift_name("endsWith(suffix:)")));
- (BOOL)endsWithSuffix_:(LostintravelsdkOkioByteString *)suffix __attribute__((swift_name("endsWith(suffix_:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)hex __attribute__((swift_name("hex()")));
- (LostintravelsdkOkioByteString *)hmacSha1Key:(LostintravelsdkOkioByteString *)key __attribute__((swift_name("hmacSha1(key:)")));
- (LostintravelsdkOkioByteString *)hmacSha256Key:(LostintravelsdkOkioByteString *)key __attribute__((swift_name("hmacSha256(key:)")));
- (LostintravelsdkOkioByteString *)hmacSha512Key:(LostintravelsdkOkioByteString *)key __attribute__((swift_name("hmacSha512(key:)")));
- (int32_t)indexOfOther:(LostintravelsdkKotlinByteArray *)other fromIndex:(int32_t)fromIndex __attribute__((swift_name("indexOf(other:fromIndex:)")));
- (int32_t)indexOfOther:(LostintravelsdkOkioByteString *)other fromIndex_:(int32_t)fromIndex __attribute__((swift_name("indexOf(other:fromIndex_:)")));
- (int32_t)lastIndexOfOther:(LostintravelsdkKotlinByteArray *)other fromIndex:(int32_t)fromIndex __attribute__((swift_name("lastIndexOf(other:fromIndex:)")));
- (int32_t)lastIndexOfOther:(LostintravelsdkOkioByteString *)other fromIndex_:(int32_t)fromIndex __attribute__((swift_name("lastIndexOf(other:fromIndex_:)")));
- (LostintravelsdkOkioByteString *)md5 __attribute__((swift_name("md5()")));
- (BOOL)rangeEqualsOffset:(int32_t)offset other:(LostintravelsdkKotlinByteArray *)other otherOffset:(int32_t)otherOffset byteCount:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:other:otherOffset:byteCount:)")));
- (BOOL)rangeEqualsOffset:(int32_t)offset other:(LostintravelsdkOkioByteString *)other otherOffset:(int32_t)otherOffset byteCount_:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:other:otherOffset:byteCount_:)")));
- (LostintravelsdkOkioByteString *)sha1 __attribute__((swift_name("sha1()")));
- (LostintravelsdkOkioByteString *)sha256 __attribute__((swift_name("sha256()")));
- (LostintravelsdkOkioByteString *)sha512 __attribute__((swift_name("sha512()")));
- (BOOL)startsWithPrefix:(LostintravelsdkKotlinByteArray *)prefix __attribute__((swift_name("startsWith(prefix:)")));
- (BOOL)startsWithPrefix_:(LostintravelsdkOkioByteString *)prefix __attribute__((swift_name("startsWith(prefix_:)")));
- (LostintravelsdkOkioByteString *)substringBeginIndex:(int32_t)beginIndex endIndex:(int32_t)endIndex __attribute__((swift_name("substring(beginIndex:endIndex:)")));
- (LostintravelsdkOkioByteString *)toAsciiLowercase __attribute__((swift_name("toAsciiLowercase()")));
- (LostintravelsdkOkioByteString *)toAsciiUppercase __attribute__((swift_name("toAsciiUppercase()")));
- (LostintravelsdkKotlinByteArray *)toByteArray __attribute__((swift_name("toByteArray()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (NSString *)utf8 __attribute__((swift_name("utf8()")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface LostintravelsdkKotlinByteArray : LostintravelsdkBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(LostintravelsdkByte *(^)(LostintravelsdkInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (LostintravelsdkKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OkioBuffer")))
@interface LostintravelsdkOkioBuffer : LostintravelsdkBase <LostintravelsdkOkioBufferedSource, LostintravelsdkOkioBufferedSink>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)clear __attribute__((swift_name("clear()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)closeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("close()")));
- (int64_t)completeSegmentByteCount __attribute__((swift_name("completeSegmentByteCount()")));
- (LostintravelsdkOkioBuffer *)doCopy __attribute__((swift_name("doCopy()")));
- (LostintravelsdkOkioBuffer *)doCopyToOut:(LostintravelsdkOkioBuffer *)out offset:(int64_t)offset __attribute__((swift_name("doCopyTo(out:offset:)")));
- (LostintravelsdkOkioBuffer *)doCopyToOut:(LostintravelsdkOkioBuffer *)out offset:(int64_t)offset byteCount:(int64_t)byteCount __attribute__((swift_name("doCopyTo(out:offset:byteCount:)")));
- (LostintravelsdkOkioBuffer *)emit __attribute__((swift_name("emit()")));
- (LostintravelsdkOkioBuffer *)emitCompleteSegments __attribute__((swift_name("emitCompleteSegments()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)flushAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("flush()")));
- (int8_t)getPos:(int64_t)pos __attribute__((swift_name("get(pos:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (LostintravelsdkOkioByteString *)hmacSha1Key:(LostintravelsdkOkioByteString *)key __attribute__((swift_name("hmacSha1(key:)")));
- (LostintravelsdkOkioByteString *)hmacSha256Key:(LostintravelsdkOkioByteString *)key __attribute__((swift_name("hmacSha256(key:)")));
- (LostintravelsdkOkioByteString *)hmacSha512Key:(LostintravelsdkOkioByteString *)key __attribute__((swift_name("hmacSha512(key:)")));
- (int64_t)indexOfB:(int8_t)b __attribute__((swift_name("indexOf(b:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(b:fromIndex:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex toIndex:(int64_t)toIndex __attribute__((swift_name("indexOf(b:fromIndex:toIndex:)")));
- (int64_t)indexOfBytes:(LostintravelsdkOkioByteString *)bytes __attribute__((swift_name("indexOf(bytes:)")));
- (int64_t)indexOfBytes:(LostintravelsdkOkioByteString *)bytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(bytes:fromIndex:)")));
- (int64_t)indexOfElementTargetBytes:(LostintravelsdkOkioByteString *)targetBytes __attribute__((swift_name("indexOfElement(targetBytes:)")));
- (int64_t)indexOfElementTargetBytes:(LostintravelsdkOkioByteString *)targetBytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOfElement(targetBytes:fromIndex:)")));
- (LostintravelsdkOkioByteString *)md5 __attribute__((swift_name("md5()")));
- (id<LostintravelsdkOkioBufferedSource>)peek __attribute__((swift_name("peek_()")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(LostintravelsdkOkioByteString *)bytes __attribute__((swift_name("rangeEquals(offset:bytes:)")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(LostintravelsdkOkioByteString *)bytes bytesOffset:(int32_t)bytesOffset byteCount:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:bytes:bytesOffset:byteCount:)")));
- (int32_t)readSink:(LostintravelsdkKotlinByteArray *)sink __attribute__((swift_name("read(sink:)")));
- (int32_t)readSink:(LostintravelsdkKotlinByteArray *)sink offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("read(sink:offset:byteCount:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (int64_t)readSink:(LostintravelsdkOkioBuffer *)sink byteCount:(int64_t)byteCount error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("read(sink:byteCount:)"))) __attribute__((swift_error(nonnull_error)));
- (int64_t)readAllSink:(id<LostintravelsdkOkioSink>)sink __attribute__((swift_name("readAll(sink:)")));
- (LostintravelsdkOkioBufferUnsafeCursor *)readAndWriteUnsafeUnsafeCursor:(LostintravelsdkOkioBufferUnsafeCursor *)unsafeCursor __attribute__((swift_name("readAndWriteUnsafe(unsafeCursor:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (LostintravelsdkKotlinByteArray *)readByteArray __attribute__((swift_name("readByteArray()")));
- (LostintravelsdkKotlinByteArray *)readByteArrayByteCount:(int64_t)byteCount __attribute__((swift_name("readByteArray(byteCount:)")));
- (LostintravelsdkOkioByteString *)readByteString __attribute__((swift_name("readByteString()")));
- (LostintravelsdkOkioByteString *)readByteStringByteCount:(int64_t)byteCount __attribute__((swift_name("readByteString(byteCount:)")));
- (int64_t)readDecimalLong __attribute__((swift_name("readDecimalLong()")));
- (void)readFullySink:(LostintravelsdkKotlinByteArray *)sink __attribute__((swift_name("readFully(sink:)")));
- (void)readFullySink:(LostintravelsdkOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readFully(sink:byteCount:)")));
- (int64_t)readHexadecimalUnsignedLong __attribute__((swift_name("readHexadecimalUnsignedLong()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int32_t)readIntLe __attribute__((swift_name("readIntLe()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int64_t)readLongLe __attribute__((swift_name("readLongLe()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (int16_t)readShortLe __attribute__((swift_name("readShortLe()")));
- (LostintravelsdkOkioBufferUnsafeCursor *)readUnsafeUnsafeCursor:(LostintravelsdkOkioBufferUnsafeCursor *)unsafeCursor __attribute__((swift_name("readUnsafe(unsafeCursor:)")));
- (NSString *)readUtf8 __attribute__((swift_name("readUtf8()")));
- (NSString *)readUtf8ByteCount:(int64_t)byteCount __attribute__((swift_name("readUtf8(byteCount:)")));
- (int32_t)readUtf8CodePoint __attribute__((swift_name("readUtf8CodePoint()")));
- (NSString * _Nullable)readUtf8Line __attribute__((swift_name("readUtf8Line()")));
- (NSString *)readUtf8LineStrict __attribute__((swift_name("readUtf8LineStrict()")));
- (NSString *)readUtf8LineStrictLimit:(int64_t)limit __attribute__((swift_name("readUtf8LineStrict(limit:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (int32_t)selectOptions:(NSArray<LostintravelsdkOkioByteString *> *)options __attribute__((swift_name("select(options:)")));
- (LostintravelsdkOkioByteString *)sha1 __attribute__((swift_name("sha1()")));
- (LostintravelsdkOkioByteString *)sha256 __attribute__((swift_name("sha256()")));
- (LostintravelsdkOkioByteString *)sha512 __attribute__((swift_name("sha512()")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
- (LostintravelsdkOkioByteString *)snapshot __attribute__((swift_name("snapshot()")));
- (LostintravelsdkOkioByteString *)snapshotByteCount:(int32_t)byteCount __attribute__((swift_name("snapshot(byteCount:)")));
- (LostintravelsdkOkioTimeout *)timeout __attribute__((swift_name("timeout()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (LostintravelsdkOkioBuffer *)writeSource:(LostintravelsdkKotlinByteArray *)source __attribute__((swift_name("write(source:)")));
- (LostintravelsdkOkioBuffer *)writeSource:(LostintravelsdkKotlinByteArray *)source offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(source:offset:byteCount:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)writeSource:(LostintravelsdkOkioBuffer *)source byteCount:(int64_t)byteCount error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("write(source:byteCount_:)")));
- (LostintravelsdkOkioBuffer *)writeByteString:(LostintravelsdkOkioByteString *)byteString __attribute__((swift_name("write(byteString:)")));
- (LostintravelsdkOkioBuffer *)writeByteString:(LostintravelsdkOkioByteString *)byteString offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(byteString:offset:byteCount:)")));
- (LostintravelsdkOkioBuffer *)writeSource:(id<LostintravelsdkOkioSource>)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
- (int64_t)writeAllSource:(id<LostintravelsdkOkioSource>)source __attribute__((swift_name("writeAll(source:)")));
- (LostintravelsdkOkioBuffer *)writeByteB:(int32_t)b __attribute__((swift_name("writeByte(b:)")));
- (LostintravelsdkOkioBuffer *)writeDecimalLongV:(int64_t)v __attribute__((swift_name("writeDecimalLong(v:)")));
- (LostintravelsdkOkioBuffer *)writeHexadecimalUnsignedLongV:(int64_t)v __attribute__((swift_name("writeHexadecimalUnsignedLong(v:)")));
- (LostintravelsdkOkioBuffer *)writeIntI:(int32_t)i __attribute__((swift_name("writeInt(i:)")));
- (LostintravelsdkOkioBuffer *)writeIntLeI:(int32_t)i __attribute__((swift_name("writeIntLe(i:)")));
- (LostintravelsdkOkioBuffer *)writeLongV:(int64_t)v __attribute__((swift_name("writeLong(v:)")));
- (LostintravelsdkOkioBuffer *)writeLongLeV:(int64_t)v __attribute__((swift_name("writeLongLe(v:)")));
- (LostintravelsdkOkioBuffer *)writeShortS:(int32_t)s __attribute__((swift_name("writeShort(s:)")));
- (LostintravelsdkOkioBuffer *)writeShortLeS:(int32_t)s __attribute__((swift_name("writeShortLe(s:)")));
- (LostintravelsdkOkioBuffer *)writeUtf8String:(NSString *)string __attribute__((swift_name("writeUtf8(string:)")));
- (LostintravelsdkOkioBuffer *)writeUtf8String:(NSString *)string beginIndex:(int32_t)beginIndex endIndex:(int32_t)endIndex __attribute__((swift_name("writeUtf8(string:beginIndex:endIndex:)")));
- (LostintravelsdkOkioBuffer *)writeUtf8CodePointCodePoint:(int32_t)codePoint __attribute__((swift_name("writeUtf8CodePoint(codePoint:)")));
@property (readonly) LostintravelsdkOkioBuffer *buffer __attribute__((swift_name("buffer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("OkioTimeout")))
@interface LostintravelsdkOkioTimeout : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) LostintravelsdkOkioTimeoutCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol LostintravelsdkKotlinCoroutineContextElement <LostintravelsdkKotlinCoroutineContext>
@required
@property (readonly) id<LostintravelsdkKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol LostintravelsdkKotlinCoroutineContextKey
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestData")))
@interface LostintravelsdkKtor_client_coreHttpRequestData : LostintravelsdkBase
- (instancetype)initWithUrl:(LostintravelsdkKtor_httpUrl *)url method:(LostintravelsdkKtor_httpHttpMethod *)method headers:(id<LostintravelsdkKtor_httpHeaders>)headers body:(LostintravelsdkKtor_httpOutgoingContent *)body executionContext:(id<LostintravelsdkKotlinx_coroutines_coreJob>)executionContext attributes:(id<LostintravelsdkKtor_utilsAttributes>)attributes __attribute__((swift_name("init(url:method:headers:body:executionContext:attributes:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getCapabilityOrNullKey:(id<LostintravelsdkKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<LostintravelsdkKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) LostintravelsdkKtor_httpOutgoingContent *body __attribute__((swift_name("body")));
@property (readonly) id<LostintravelsdkKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<LostintravelsdkKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) LostintravelsdkKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) LostintravelsdkKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseData")))
@interface LostintravelsdkKtor_client_coreHttpResponseData : LostintravelsdkBase
- (instancetype)initWithStatusCode:(LostintravelsdkKtor_httpHttpStatusCode *)statusCode requestTime:(LostintravelsdkKtor_utilsGMTDate *)requestTime headers:(id<LostintravelsdkKtor_httpHeaders>)headers version:(LostintravelsdkKtor_httpHttpProtocolVersion *)version body:(id)body callContext:(id<LostintravelsdkKotlinCoroutineContext>)callContext __attribute__((swift_name("init(statusCode:requestTime:headers:version:body:callContext:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id body __attribute__((swift_name("body")));
@property (readonly) id<LostintravelsdkKotlinCoroutineContext> callContext __attribute__((swift_name("callContext")));
@property (readonly) id<LostintravelsdkKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) LostintravelsdkKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) LostintravelsdkKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *statusCode __attribute__((swift_name("statusCode")));
@property (readonly) LostintravelsdkKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface LostintravelsdkKotlinAbstractCoroutineContextElement : LostintravelsdkBase <LostintravelsdkKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<LostintravelsdkKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<LostintravelsdkKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol LostintravelsdkKotlinContinuationInterceptor <LostintravelsdkKotlinCoroutineContextElement>
@required
- (id<LostintravelsdkKotlinContinuation>)interceptContinuationContinuation:(id<LostintravelsdkKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<LostintravelsdkKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface LostintravelsdkKotlinx_coroutines_coreCoroutineDispatcher : LostintravelsdkKotlinAbstractCoroutineContextElement <LostintravelsdkKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<LostintravelsdkKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) LostintravelsdkKotlinx_coroutines_coreCoroutineDispatcherKey *companion __attribute__((swift_name("companion")));
- (void)dispatchContext:(id<LostintravelsdkKotlinCoroutineContext>)context block:(id<LostintravelsdkKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));
- (void)dispatchYieldContext:(id<LostintravelsdkKotlinCoroutineContext>)context block:(id<LostintravelsdkKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<LostintravelsdkKotlinContinuation>)interceptContinuationContinuation:(id<LostintravelsdkKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<LostintravelsdkKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (LostintravelsdkKotlinx_coroutines_coreCoroutineDispatcher *)limitedParallelismParallelism:(int32_t)parallelism __attribute__((swift_name("limitedParallelism(parallelism:)")));
- (LostintravelsdkKotlinx_coroutines_coreCoroutineDispatcher *)plusOther:(LostintravelsdkKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<LostintravelsdkKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreProxyConfig")))
@interface LostintravelsdkKtor_client_coreProxyConfig : LostintravelsdkBase
- (instancetype)initWithUrl:(LostintravelsdkKtor_httpUrl *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) LostintravelsdkKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientPlugin")))
@protocol LostintravelsdkKtor_client_coreHttpClientPlugin
@required
- (void)installPlugin:(id)plugin scope:(LostintravelsdkKtor_client_coreHttpClient *)scope __attribute__((swift_name("install(plugin:scope:)")));
- (id)prepareBlock:(void (^)(id))block __attribute__((swift_name("prepare(block:)")));
@property (readonly) LostintravelsdkKtor_utilsAttributeKey<id> *key __attribute__((swift_name("key")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsAttributeKey")))
@interface LostintravelsdkKtor_utilsAttributeKey<T> : LostintravelsdkBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("Ktor_eventsEventDefinition")))
@interface LostintravelsdkKtor_eventsEventDefinition<T> : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreDisposableHandle")))
@protocol LostintravelsdkKotlinx_coroutines_coreDisposableHandle
@required
- (void)dispose __attribute__((swift_name("dispose()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsPipelinePhase")))
@interface LostintravelsdkKtor_utilsPipelinePhase : LostintravelsdkBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("KotlinFunction")))
@protocol LostintravelsdkKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction2")))
@protocol LostintravelsdkKotlinSuspendFunction2 <LostintravelsdkKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 p2:(id _Nullable)p2 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:p2:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline.Phases")))
@interface LostintravelsdkKtor_client_coreHttpReceivePipelinePhases : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_client_coreHttpReceivePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end

__attribute__((swift_name("Ktor_httpHttpMessage")))
@protocol LostintravelsdkKtor_httpHttpMessage
@required
@property (readonly) id<LostintravelsdkKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@end

__attribute__((swift_name("Ktor_client_coreHttpResponse")))
@interface LostintravelsdkKtor_client_coreHttpResponse : LostintravelsdkBase <LostintravelsdkKtor_httpHttpMessage, LostintravelsdkKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) LostintravelsdkKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) id<LostintravelsdkKtor_ioByteReadChannel> content __attribute__((swift_name("content")));
@property (readonly) LostintravelsdkKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) LostintravelsdkKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *status __attribute__((swift_name("status")));
@property (readonly) LostintravelsdkKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface LostintravelsdkKotlinUnit : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline.Phases")))
@interface LostintravelsdkKtor_client_coreHttpRequestPipelinePhases : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_client_coreHttpRequestPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *Render __attribute__((swift_name("Render")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *Send __attribute__((swift_name("Send")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end

__attribute__((swift_name("Ktor_httpHttpMessageBuilder")))
@protocol LostintravelsdkKtor_httpHttpMessageBuilder
@required
@property (readonly) LostintravelsdkKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder")))
@interface LostintravelsdkKtor_client_coreHttpRequestBuilder : LostintravelsdkBase <LostintravelsdkKtor_httpHttpMessageBuilder>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) LostintravelsdkKtor_client_coreHttpRequestBuilderCompanion *companion __attribute__((swift_name("companion")));
- (LostintravelsdkKtor_client_coreHttpRequestData *)build __attribute__((swift_name("build()")));
- (id _Nullable)getCapabilityOrNullKey:(id<LostintravelsdkKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (void)setAttributesBlock:(void (^)(id<LostintravelsdkKtor_utilsAttributes>))block __attribute__((swift_name("setAttributes(block:)")));
- (void)setCapabilityKey:(id<LostintravelsdkKtor_client_coreHttpClientEngineCapability>)key capability:(id)capability __attribute__((swift_name("setCapability(key:capability:)")));
- (LostintravelsdkKtor_client_coreHttpRequestBuilder *)takeFromBuilder:(LostintravelsdkKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFrom(builder:)")));
- (LostintravelsdkKtor_client_coreHttpRequestBuilder *)takeFromWithExecutionContextBuilder:(LostintravelsdkKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFromWithExecutionContext(builder:)")));
- (void)urlBlock:(void (^)(LostintravelsdkKtor_httpURLBuilder *, LostintravelsdkKtor_httpURLBuilder *))block __attribute__((swift_name("url(block:)")));
@property (readonly) id<LostintravelsdkKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property id body __attribute__((swift_name("body")));
@property LostintravelsdkKtor_utilsTypeInfo * _Nullable bodyType __attribute__((swift_name("bodyType")));
@property (readonly) id<LostintravelsdkKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) LostintravelsdkKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@property LostintravelsdkKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) LostintravelsdkKtor_httpURLBuilder *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline.Phases")))
@interface LostintravelsdkKtor_client_coreHttpResponsePipelinePhases : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_client_coreHttpResponsePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *Parse __attribute__((swift_name("Parse")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseContainer")))
@interface LostintravelsdkKtor_client_coreHttpResponseContainer : LostintravelsdkBase
- (instancetype)initWithExpectedType:(LostintravelsdkKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("init(expectedType:response:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkKtor_client_coreHttpResponseContainer *)doCopyExpectedType:(LostintravelsdkKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("doCopy(expectedType:response:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) LostintravelsdkKtor_utilsTypeInfo *expectedType __attribute__((swift_name("expectedType")));
@property (readonly) id response __attribute__((swift_name("response")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientCall")))
@interface LostintravelsdkKtor_client_coreHttpClientCall : LostintravelsdkBase <LostintravelsdkKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithClient:(LostintravelsdkKtor_client_coreHttpClient *)client requestData:(LostintravelsdkKtor_client_coreHttpRequestData *)requestData responseData:(LostintravelsdkKtor_client_coreHttpResponseData *)responseData __attribute__((swift_name("init(client:requestData:responseData:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithClient:(LostintravelsdkKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkKtor_client_coreHttpClientCallCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyInfo:(LostintravelsdkKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("body(info:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyNullableInfo:(LostintravelsdkKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("bodyNullable(info:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)getResponseContentWithCompletionHandler:(void (^)(id<LostintravelsdkKtor_ioByteReadChannel> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getResponseContent(completionHandler:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) BOOL allowDoubleReceive __attribute__((swift_name("allowDoubleReceive")));
@property (readonly) id<LostintravelsdkKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) LostintravelsdkKtor_client_coreHttpClient *client __attribute__((swift_name("client")));
@property (readonly) id<LostintravelsdkKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property id<LostintravelsdkKtor_client_coreHttpRequest> request __attribute__((swift_name("request")));
@property LostintravelsdkKtor_client_coreHttpResponse *response __attribute__((swift_name("response")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline.Phases")))
@interface LostintravelsdkKtor_client_coreHttpSendPipelinePhases : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_client_coreHttpSendPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *Engine __attribute__((swift_name("Engine")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *Monitoring __attribute__((swift_name("Monitoring")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) LostintravelsdkKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiApolloRequestBuilder")))
@interface LostintravelsdkApollo_apiApolloRequestBuilder<D> : LostintravelsdkBase <LostintravelsdkApollo_apiMutableExecutionOptions>
- (instancetype)initWithOperation:(id<LostintravelsdkApollo_apiOperation>)operation __attribute__((swift_name("init(operation:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkApollo_apiApolloRequestBuilder<D> *)addExecutionContextExecutionContext:(id<LostintravelsdkApollo_apiExecutionContext>)executionContext __attribute__((swift_name("addExecutionContext(executionContext:)")));
- (LostintravelsdkApollo_apiApolloRequestBuilder<D> *)addHttpHeaderName:(NSString *)name value:(NSString *)value __attribute__((swift_name("addHttpHeader(name:value:)")));
- (LostintravelsdkApollo_apiApolloRequest<D> *)build __attribute__((swift_name("build()")));
- (LostintravelsdkApollo_apiApolloRequestBuilder<D> *)canBeBatchedCanBeBatched:(LostintravelsdkBoolean * _Nullable)canBeBatched __attribute__((swift_name("canBeBatched(canBeBatched:)")));
- (LostintravelsdkApollo_apiApolloRequestBuilder<D> *)enableAutoPersistedQueriesEnableAutoPersistedQueries:(LostintravelsdkBoolean * _Nullable)enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries(enableAutoPersistedQueries:)")));
- (LostintravelsdkApollo_apiApolloRequestBuilder<D> *)executionContextExecutionContext:(id<LostintravelsdkApollo_apiExecutionContext>)executionContext __attribute__((swift_name("executionContext(executionContext:)")));
- (LostintravelsdkApollo_apiApolloRequestBuilder<D> *)httpHeadersHttpHeaders:(NSArray<LostintravelsdkApollo_apiHttpHeader *> * _Nullable)httpHeaders __attribute__((swift_name("httpHeaders(httpHeaders:)")));
- (LostintravelsdkApollo_apiApolloRequestBuilder<D> *)httpMethodHttpMethod:(LostintravelsdkApollo_apiHttpMethod * _Nullable)httpMethod __attribute__((swift_name("httpMethod(httpMethod:)")));
- (LostintravelsdkApollo_apiApolloRequestBuilder<D> *)requestUuidRequestUuid:(LostintravelsdkUuidUuid *)requestUuid __attribute__((swift_name("requestUuid(requestUuid:)")));
- (LostintravelsdkApollo_apiApolloRequestBuilder<D> *)sendApqExtensionsSendApqExtensions:(LostintravelsdkBoolean * _Nullable)sendApqExtensions __attribute__((swift_name("sendApqExtensions(sendApqExtensions:)")));
- (LostintravelsdkApollo_apiApolloRequestBuilder<D> *)sendDocumentSendDocument:(LostintravelsdkBoolean * _Nullable)sendDocument __attribute__((swift_name("sendDocument(sendDocument:)")));
@property LostintravelsdkBoolean * _Nullable canBeBatched __attribute__((swift_name("canBeBatched")));
@property LostintravelsdkBoolean * _Nullable enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries")));
@property id<LostintravelsdkApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property NSArray<LostintravelsdkApollo_apiHttpHeader *> * _Nullable httpHeaders __attribute__((swift_name("httpHeaders")));
@property LostintravelsdkApollo_apiHttpMethod * _Nullable httpMethod __attribute__((swift_name("httpMethod")));
@property LostintravelsdkBoolean * _Nullable sendApqExtensions __attribute__((swift_name("sendApqExtensions")));
@property LostintravelsdkBoolean * _Nullable sendDocument __attribute__((swift_name("sendDocument")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UuidUuid")))
@interface LostintravelsdkUuidUuid : LostintravelsdkBase <LostintravelsdkKotlinComparable>
- (instancetype)initWithMsb:(int64_t)msb lsb:(int64_t)lsb __attribute__((swift_name("init(msb:lsb:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithUuidBytes:(LostintravelsdkKotlinByteArray *)uuidBytes __attribute__((swift_name("init(uuidBytes:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use `uuidOf` instead.")));
- (int32_t)compareToOther:(LostintravelsdkUuidUuid *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t leastSignificantBits __attribute__((swift_name("leastSignificantBits")));
@property (readonly) int64_t mostSignificantBits __attribute__((swift_name("mostSignificantBits")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiApolloResponse")))
@interface LostintravelsdkApollo_apiApolloResponse<D> : LostintravelsdkBase
- (BOOL)hasErrors __attribute__((swift_name("hasErrors()")));
- (LostintravelsdkApollo_apiApolloResponseBuilder<D> *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));
@property (readonly) D _Nullable data __attribute__((swift_name("data")));
@property (readonly) D dataAssertNoErrors __attribute__((swift_name("dataAssertNoErrors")));
@property (readonly) NSArray<LostintravelsdkApollo_apiError *> * _Nullable errors __attribute__((swift_name("errors")));
@property (readonly) id<LostintravelsdkApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) NSDictionary<NSString *, id> *extensions __attribute__((swift_name("extensions")));
@property (readonly) id<LostintravelsdkApollo_apiOperation> operation __attribute__((swift_name("operation")));
@property (readonly) LostintravelsdkUuidUuid *requestUuid __attribute__((swift_name("requestUuid")));
@end

__attribute__((swift_name("Apollo_runtimeHttpEngine")))
@protocol LostintravelsdkApollo_runtimeHttpEngine
@required
- (void)dispose __attribute__((swift_name("dispose()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeRequest:(LostintravelsdkApollo_apiHttpRequest *)request completionHandler:(void (^)(LostintravelsdkApollo_apiHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(request:completionHandler:)")));
@end

__attribute__((swift_name("Apollo_runtimeWebSocketEngine")))
@protocol LostintravelsdkApollo_runtimeWebSocketEngine
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)openUrl:(NSString *)url headers:(NSDictionary<NSString *, NSString *> *)headers completionHandler:(void (^)(id<LostintravelsdkApollo_runtimeWebSocketConnection> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("open(url:headers:completionHandler:)")));
@end

__attribute__((swift_name("Apollo_runtimeWsProtocolFactory")))
@protocol LostintravelsdkApollo_runtimeWsProtocolFactory
@required
- (LostintravelsdkApollo_runtimeWsProtocol *)createWebSocketConnection:(id<LostintravelsdkApollo_runtimeWebSocketConnection>)webSocketConnection listener:(id<LostintravelsdkApollo_runtimeWsProtocolListener>)listener scope:(id<LostintravelsdkKotlinx_coroutines_coreCoroutineScope>)scope __attribute__((swift_name("create(webSocketConnection:listener:scope:)")));
@property (readonly, getter=name_) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("Apollo_runtimeApolloInterceptorChain")))
@protocol LostintravelsdkApollo_runtimeApolloInterceptorChain
@required
- (id<LostintravelsdkKotlinx_coroutines_coreFlow>)proceedRequest:(LostintravelsdkApollo_apiApolloRequest<id<LostintravelsdkApollo_apiOperationData>> *)request __attribute__((swift_name("proceed(request:)")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol LostintravelsdkKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<LostintravelsdkKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<LostintravelsdkKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<LostintravelsdkKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) LostintravelsdkKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface LostintravelsdkKotlinx_serialization_coreSerializersModule : LostintravelsdkBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<LostintravelsdkKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<LostintravelsdkKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<LostintravelsdkKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<LostintravelsdkKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<LostintravelsdkKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<LostintravelsdkKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<LostintravelsdkKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<LostintravelsdkKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol LostintravelsdkKotlinAnnotation
@required
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface LostintravelsdkKotlinx_serialization_coreSerialKind : LostintravelsdkBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol LostintravelsdkKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<LostintravelsdkKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<LostintravelsdkKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<LostintravelsdkKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<LostintravelsdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) LostintravelsdkKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Apollo_apiCustomTypeValue")))
@interface LostintravelsdkApollo_apiCustomTypeValue<T> : LostintravelsdkBase
@property (class, readonly, getter=companion) LostintravelsdkApollo_apiCustomTypeValueCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) T _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OkioByteString.Companion")))
@interface LostintravelsdkOkioByteStringCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkOkioByteStringCompanion *shared __attribute__((swift_name("shared")));
- (LostintravelsdkOkioByteString *)ofData:(LostintravelsdkKotlinByteArray *)data __attribute__((swift_name("of(data:)")));
- (LostintravelsdkOkioByteString * _Nullable)decodeBase64:(NSString *)receiver __attribute__((swift_name("decodeBase64(_:)")));
- (LostintravelsdkOkioByteString *)decodeHex:(NSString *)receiver __attribute__((swift_name("decodeHex(_:)")));
- (LostintravelsdkOkioByteString *)encodeUtf8:(NSString *)receiver __attribute__((swift_name("encodeUtf8(_:)")));
- (LostintravelsdkOkioByteString *)toByteString:(LostintravelsdkKotlinByteArray *)receiver offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("toByteString(_:offset:byteCount:)")));
@property (readonly) LostintravelsdkOkioByteString *EMPTY __attribute__((swift_name("EMPTY")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface LostintravelsdkKotlinByteIterator : LostintravelsdkBase <LostintravelsdkKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (LostintravelsdkByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OkioBuffer.UnsafeCursor")))
@interface LostintravelsdkOkioBufferUnsafeCursor : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)close __attribute__((swift_name("close()")));
- (int64_t)expandBufferMinByteCount:(int32_t)minByteCount __attribute__((swift_name("expandBuffer(minByteCount:)")));
- (int32_t)next __attribute__((swift_name("next()")));
- (int64_t)resizeBufferNewSize:(int64_t)newSize __attribute__((swift_name("resizeBuffer(newSize:)")));
- (int32_t)seekOffset:(int64_t)offset __attribute__((swift_name("seek(offset:)")));
@property LostintravelsdkOkioBuffer * _Nullable buffer __attribute__((swift_name("buffer")));
@property LostintravelsdkKotlinByteArray * _Nullable data __attribute__((swift_name("data")));
@property int32_t end __attribute__((swift_name("end")));
@property int64_t offset __attribute__((swift_name("offset")));
@property BOOL readWrite __attribute__((swift_name("readWrite")));
@property int32_t start __attribute__((swift_name("start")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OkioTimeout.Companion")))
@interface LostintravelsdkOkioTimeoutCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkOkioTimeoutCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkOkioTimeout *NONE __attribute__((swift_name("NONE")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl")))
@interface LostintravelsdkKtor_httpUrl : LostintravelsdkBase
@property (class, readonly, getter=companion) LostintravelsdkKtor_httpUrlCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property (readonly) NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property (readonly) NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property (readonly) NSString *encodedPathAndQuery __attribute__((swift_name("encodedPathAndQuery")));
@property (readonly) NSString *encodedQuery __attribute__((swift_name("encodedQuery")));
@property (readonly) NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property (readonly) NSString *fragment __attribute__((swift_name("fragment")));
@property (readonly) NSString *host __attribute__((swift_name("host")));
@property (readonly) id<LostintravelsdkKtor_httpParameters> parameters __attribute__((swift_name("parameters")));
@property (readonly) NSString * _Nullable password __attribute__((swift_name("password")));
@property (readonly) NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments")));
@property (readonly) int32_t port __attribute__((swift_name("port")));
@property (readonly) LostintravelsdkKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property (readonly) int32_t specifiedPort __attribute__((swift_name("specifiedPort")));
@property (readonly) BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property (readonly) NSString * _Nullable user __attribute__((swift_name("user")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod")))
@interface LostintravelsdkKtor_httpHttpMethod : LostintravelsdkBase
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkKtor_httpHttpMethodCompanion *companion __attribute__((swift_name("companion")));
- (LostintravelsdkKtor_httpHttpMethod *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("Ktor_utilsStringValues")))
@protocol LostintravelsdkKtor_utilsStringValues
@required
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<LostintravelsdkKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (void)forEachBody:(void (^)(NSString *, NSArray<NSString *> *))body __attribute__((swift_name("forEach(body:)")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end

__attribute__((swift_name("Ktor_httpHeaders")))
@protocol LostintravelsdkKtor_httpHeaders <LostintravelsdkKtor_utilsStringValues>
@required
@end

__attribute__((swift_name("Ktor_httpOutgoingContent")))
@interface LostintravelsdkKtor_httpOutgoingContent : LostintravelsdkBase
- (id _Nullable)getPropertyKey:(LostintravelsdkKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getProperty(key:)")));
- (void)setPropertyKey:(LostintravelsdkKtor_utilsAttributeKey<id> *)key value:(id _Nullable)value __attribute__((swift_name("setProperty(key:value:)")));
- (id<LostintravelsdkKtor_httpHeaders> _Nullable)trailers __attribute__((swift_name("trailers()")));
@property (readonly) LostintravelsdkLong * _Nullable contentLength_ __attribute__((swift_name("contentLength_")));
@property (readonly) LostintravelsdkKtor_httpContentType * _Nullable contentType __attribute__((swift_name("contentType")));
@property (readonly) id<LostintravelsdkKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode * _Nullable status __attribute__((swift_name("status")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreJob")))
@protocol LostintravelsdkKotlinx_coroutines_coreJob <LostintravelsdkKotlinCoroutineContextElement>
@required
- (id<LostintravelsdkKotlinx_coroutines_coreChildHandle>)attachChildChild:(id<LostintravelsdkKotlinx_coroutines_coreChildJob>)child __attribute__((swift_name("attachChild(child:)")));
- (void)cancelCause:(LostintravelsdkKotlinCancellationException * _Nullable)cause __attribute__((swift_name("cancel(cause:)")));
- (LostintravelsdkKotlinCancellationException *)getCancellationException __attribute__((swift_name("getCancellationException()")));
- (id<LostintravelsdkKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionOnCancelling:(BOOL)onCancelling invokeImmediately:(BOOL)invokeImmediately handler:(void (^)(LostintravelsdkKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(onCancelling:invokeImmediately:handler:)")));
- (id<LostintravelsdkKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionHandler:(void (^)(LostintravelsdkKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(handler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)joinWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("join(completionHandler:)")));
- (id<LostintravelsdkKotlinx_coroutines_coreJob>)plusOther_:(id<LostintravelsdkKotlinx_coroutines_coreJob>)other __attribute__((swift_name("plus(other_:)"))) __attribute__((unavailable("Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")));
- (BOOL)start __attribute__((swift_name("start()")));
@property (readonly) id<LostintravelsdkKotlinSequence> children __attribute__((swift_name("children")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isCancelled __attribute__((swift_name("isCancelled")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property (readonly) id<LostintravelsdkKotlinx_coroutines_coreSelectClause0> onJoin __attribute__((swift_name("onJoin")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode")))
@interface LostintravelsdkKtor_httpHttpStatusCode : LostintravelsdkBase
- (instancetype)initWithValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("init(value:description:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkKtor_httpHttpStatusCodeCompanion *companion __attribute__((swift_name("companion")));
- (LostintravelsdkKtor_httpHttpStatusCode *)doCopyValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("doCopy(value:description:)")));
- (LostintravelsdkKtor_httpHttpStatusCode *)descriptionValue:(NSString *)value __attribute__((swift_name("description(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate")))
@interface LostintravelsdkKtor_utilsGMTDate : LostintravelsdkBase <LostintravelsdkKotlinComparable>
@property (class, readonly, getter=companion) LostintravelsdkKtor_utilsGMTDateCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(LostintravelsdkKtor_utilsGMTDate *)other __attribute__((swift_name("compareTo(other:)")));
- (LostintravelsdkKtor_utilsGMTDate *)doCopySeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(LostintravelsdkKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(LostintravelsdkKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("doCopy(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) LostintravelsdkKtor_utilsWeekDay *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) int32_t hours __attribute__((swift_name("hours")));
@property (readonly) int32_t minutes __attribute__((swift_name("minutes")));
@property (readonly) LostintravelsdkKtor_utilsMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t seconds __attribute__((swift_name("seconds")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion")))
@interface LostintravelsdkKtor_httpHttpProtocolVersion : LostintravelsdkBase
- (instancetype)initWithName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("init(name:major:minor:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkKtor_httpHttpProtocolVersionCompanion *companion __attribute__((swift_name("companion")));
- (LostintravelsdkKtor_httpHttpProtocolVersion *)doCopyName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("doCopy(name:major:minor:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t major __attribute__((swift_name("major")));
@property (readonly) int32_t minor __attribute__((swift_name("minor")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuation")))
@protocol LostintravelsdkKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<LostintravelsdkKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextKey")))
@interface LostintravelsdkKotlinAbstractCoroutineContextKey<B, E> : LostintravelsdkBase <LostintravelsdkKotlinCoroutineContextKey>
- (instancetype)initWithBaseKey:(id<LostintravelsdkKotlinCoroutineContextKey>)baseKey safeCast:(E _Nullable (^)(id<LostintravelsdkKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher.Key")))
@interface LostintravelsdkKotlinx_coroutines_coreCoroutineDispatcherKey : LostintravelsdkKotlinAbstractCoroutineContextKey<id<LostintravelsdkKotlinContinuationInterceptor>, LostintravelsdkKotlinx_coroutines_coreCoroutineDispatcher *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithBaseKey:(id<LostintravelsdkKotlinCoroutineContextKey>)baseKey safeCast:(id<LostintravelsdkKotlinCoroutineContextElement> _Nullable (^)(id<LostintravelsdkKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKotlinx_coroutines_coreCoroutineDispatcherKey *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol LostintravelsdkKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end

__attribute__((swift_name("Ktor_ioByteReadChannel")))
@protocol LostintravelsdkKtor_ioByteReadChannel
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)awaitContentWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("awaitContent(completionHandler:)")));
- (BOOL)cancelCause_:(LostintravelsdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("cancel(cause_:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)discardMax:(int64_t)max completionHandler:(void (^)(LostintravelsdkLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("discard(max:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)peekToDestination:(LostintravelsdkKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max completionHandler:(void (^)(LostintravelsdkLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(LostintravelsdkKtor_ioChunkBuffer *)dst completionHandler:(void (^)(LostintravelsdkInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(LostintravelsdkKotlinByteArray *)dst offset:(int32_t)offset length:(int32_t)length completionHandler:(void (^)(LostintravelsdkInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler:)")));
- (int32_t)readAvailableMin:(int32_t)min block:(void (^)(LostintravelsdkKtor_ioBuffer *))block __attribute__((swift_name("readAvailable(min:block:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(void *)dst offset:(int32_t)offset length:(int32_t)length completionHandler_:(void (^)(LostintravelsdkInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler_:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(void *)dst offset:(int64_t)offset length:(int64_t)length completionHandler__:(void (^)(LostintravelsdkInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler__:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readBooleanWithCompletionHandler:(void (^)(LostintravelsdkBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readBoolean(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readByteWithCompletionHandler:(void (^)(LostintravelsdkByte * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readByte(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readDoubleWithCompletionHandler:(void (^)(LostintravelsdkDouble * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readDouble(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFloatWithCompletionHandler:(void (^)(LostintravelsdkFloat * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readFloat(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(LostintravelsdkKtor_ioChunkBuffer *)dst n:(int32_t)n completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:n:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(LostintravelsdkKotlinByteArray *)dst offset:(int32_t)offset length:(int32_t)length completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(void *)dst offset:(int32_t)offset length:(int32_t)length completionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler_:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(void *)dst offset:(int64_t)offset length:(int64_t)length completionHandler__:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler__:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readIntWithCompletionHandler:(void (^)(LostintravelsdkInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readInt(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readLongWithCompletionHandler:(void (^)(LostintravelsdkLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readLong(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readPacketSize:(int32_t)size completionHandler:(void (^)(LostintravelsdkKtor_ioByteReadPacket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readPacket(size:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readRemainingLimit:(int64_t)limit completionHandler:(void (^)(LostintravelsdkKtor_ioByteReadPacket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readRemaining(limit:completionHandler:)")));
- (void)readSessionConsumer:(void (^)(id<LostintravelsdkKtor_ioReadSession>))consumer __attribute__((swift_name("readSession(consumer:)"))) __attribute__((deprecated("Use read { } instead.")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readShortWithCompletionHandler:(void (^)(LostintravelsdkShort * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readShort(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readSuspendableSessionConsumer:(id<LostintravelsdkKotlinSuspendFunction1>)consumer completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("readSuspendableSession(consumer:completionHandler:)"))) __attribute__((deprecated("Use read { } instead.")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readUTF8LineLimit:(int32_t)limit completionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("readUTF8Line(limit:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readUTF8LineToOut:(id<LostintravelsdkKotlinAppendable>)out limit:(int32_t)limit completionHandler:(void (^)(LostintravelsdkBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readUTF8LineTo(out:limit:completionHandler:)")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@property (readonly) LostintravelsdkKotlinThrowable * _Nullable closedCause __attribute__((swift_name("closedCause")));
@property (readonly) BOOL isClosedForRead __attribute__((swift_name("isClosedForRead")));
@property (readonly) BOOL isClosedForWrite __attribute__((swift_name("isClosedForWrite")));
@property (readonly) int64_t totalBytesRead __attribute__((swift_name("totalBytesRead")));
@end

__attribute__((swift_name("Ktor_utilsStringValuesBuilder")))
@protocol LostintravelsdkKtor_utilsStringValuesBuilder
@required
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<LostintravelsdkKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<LostintravelsdkKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<LostintravelsdkKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<LostintravelsdkKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end

__attribute__((swift_name("Ktor_utilsStringValuesBuilderImpl")))
@interface LostintravelsdkKtor_utilsStringValuesBuilderImpl : LostintravelsdkBase <LostintravelsdkKtor_utilsStringValuesBuilder>
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer));
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<LostintravelsdkKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<LostintravelsdkKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<LostintravelsdkKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<LostintravelsdkKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) LostintravelsdkMutableDictionary<NSString *, NSMutableArray<NSString *> *> *values __attribute__((swift_name("values")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeadersBuilder")))
@interface LostintravelsdkKtor_httpHeadersBuilder : LostintravelsdkKtor_utilsStringValuesBuilderImpl
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<LostintravelsdkKtor_httpHeaders>)build __attribute__((swift_name("build()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder.Companion")))
@interface LostintravelsdkKtor_client_coreHttpRequestBuilderCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_client_coreHttpRequestBuilderCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder")))
@interface LostintravelsdkKtor_httpURLBuilder : LostintravelsdkBase
- (instancetype)initWithProtocol:(LostintravelsdkKtor_httpURLProtocol *)protocol host:(NSString *)host port:(int32_t)port user:(NSString * _Nullable)user password:(NSString * _Nullable)password pathSegments:(NSArray<NSString *> *)pathSegments parameters:(id<LostintravelsdkKtor_httpParameters>)parameters fragment:(NSString *)fragment trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:port:user:password:pathSegments:parameters:fragment:trailingQuery:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkKtor_httpURLBuilderCompanion *companion __attribute__((swift_name("companion")));
- (LostintravelsdkKtor_httpUrl *)build __attribute__((swift_name("build()")));
- (NSString *)buildString __attribute__((swift_name("buildString()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property id<LostintravelsdkKtor_httpParametersBuilder> encodedParameters __attribute__((swift_name("encodedParameters")));
@property NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property NSArray<NSString *> *encodedPathSegments __attribute__((swift_name("encodedPathSegments")));
@property NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property NSString *fragment __attribute__((swift_name("fragment")));
@property NSString *host __attribute__((swift_name("host")));
@property (readonly) id<LostintravelsdkKtor_httpParametersBuilder> parameters __attribute__((swift_name("parameters")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments")));
@property int32_t port __attribute__((swift_name("port")));
@property LostintravelsdkKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property NSString * _Nullable user __attribute__((swift_name("user")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsTypeInfo")))
@interface LostintravelsdkKtor_utilsTypeInfo : LostintravelsdkBase
- (instancetype)initWithType:(id<LostintravelsdkKotlinKClass>)type reifiedType:(id<LostintravelsdkKotlinKType>)reifiedType kotlinType:(id<LostintravelsdkKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:reifiedType:kotlinType:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkKtor_utilsTypeInfo *)doCopyType:(id<LostintravelsdkKotlinKClass>)type reifiedType:(id<LostintravelsdkKotlinKType>)reifiedType kotlinType:(id<LostintravelsdkKotlinKType> _Nullable)kotlinType __attribute__((swift_name("doCopy(type:reifiedType:kotlinType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<LostintravelsdkKotlinKType> _Nullable kotlinType __attribute__((swift_name("kotlinType")));
@property (readonly) id<LostintravelsdkKotlinKType> reifiedType __attribute__((swift_name("reifiedType")));
@property (readonly) id<LostintravelsdkKotlinKClass> type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientCall.Companion")))
@interface LostintravelsdkKtor_client_coreHttpClientCallCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_client_coreHttpClientCallCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkKtor_utilsAttributeKey<id> *CustomResponse __attribute__((swift_name("CustomResponse"))) __attribute__((unavailable("This is going to be removed. Please file a ticket with clarification why and what for do you need it.")));
@end

__attribute__((swift_name("Ktor_client_coreHttpRequest")))
@protocol LostintravelsdkKtor_client_coreHttpRequest <LostintravelsdkKtor_httpHttpMessage, LostintravelsdkKotlinx_coroutines_coreCoroutineScope>
@required
@property (readonly) id<LostintravelsdkKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) LostintravelsdkKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) LostintravelsdkKtor_httpOutgoingContent *content __attribute__((swift_name("content")));
@property (readonly) LostintravelsdkKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) LostintravelsdkKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiApolloResponseBuilder")))
@interface LostintravelsdkApollo_apiApolloResponseBuilder<D> : LostintravelsdkBase
- (instancetype)initWithOperation:(id<LostintravelsdkApollo_apiOperation>)operation requestUuid:(LostintravelsdkUuidUuid *)requestUuid data:(D _Nullable)data __attribute__((swift_name("init(operation:requestUuid:data:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkApollo_apiApolloResponseBuilder<D> *)addExecutionContextExecutionContext:(id<LostintravelsdkApollo_apiExecutionContext>)executionContext __attribute__((swift_name("addExecutionContext(executionContext:)")));
- (LostintravelsdkApollo_apiApolloResponse<D> *)build __attribute__((swift_name("build()")));
- (LostintravelsdkApollo_apiApolloResponseBuilder<D> *)errorsErrors:(NSArray<LostintravelsdkApollo_apiError *> * _Nullable)errors __attribute__((swift_name("errors(errors:)")));
- (LostintravelsdkApollo_apiApolloResponseBuilder<D> *)extensionsExtensions:(NSDictionary<NSString *, id> * _Nullable)extensions __attribute__((swift_name("extensions(extensions:)")));
- (LostintravelsdkApollo_apiApolloResponseBuilder<D> *)requestUuidRequestUuid:(LostintravelsdkUuidUuid *)requestUuid __attribute__((swift_name("requestUuid(requestUuid:)")));
@end

__attribute__((swift_name("Apollo_runtimeWebSocketConnection")))
@protocol LostintravelsdkApollo_runtimeWebSocketConnection
@required
- (void)close __attribute__((swift_name("close_()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)receiveWithCompletionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("receive(completionHandler:)")));
- (void)sendString:(NSString *)string __attribute__((swift_name("send(string:)")));
- (void)sendData:(LostintravelsdkOkioByteString *)data __attribute__((swift_name("send(data:)")));
@end

__attribute__((swift_name("Apollo_runtimeWsProtocol")))
@interface LostintravelsdkApollo_runtimeWsProtocol : LostintravelsdkBase
- (instancetype)initWithWebSocketConnection:(id<LostintravelsdkApollo_runtimeWebSocketConnection>)webSocketConnection listener:(id<LostintravelsdkApollo_runtimeWsProtocolListener>)listener __attribute__((swift_name("init(webSocketConnection:listener:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close_()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)connectionInitWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("connectionInit(completionHandler:)")));
- (void)handleServerMessageMessageMap:(NSDictionary<NSString *, id> *)messageMap __attribute__((swift_name("handleServerMessage(messageMap:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)receiveMessageMapWithCompletionHandler:(void (^)(NSDictionary<NSString *, id> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("receiveMessageMap(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)runWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("run(completionHandler:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)sendMessageMapMessageMap:(NSDictionary<NSString *, id> *)messageMap frameType:(LostintravelsdkApollo_runtimeWsFrameType *)frameType __attribute__((swift_name("sendMessageMap(messageMap:frameType:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)sendMessageMapBinaryMessageMap:(NSDictionary<NSString *, id> *)messageMap __attribute__((swift_name("sendMessageMapBinary(messageMap:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)sendMessageMapTextMessageMap:(NSDictionary<NSString *, id> *)messageMap __attribute__((swift_name("sendMessageMapText(messageMap:)")));
- (void)startOperationRequest:(LostintravelsdkApollo_apiApolloRequest<id<LostintravelsdkApollo_apiOperationData>> *)request __attribute__((swift_name("startOperation(request:)")));
- (void)stopOperationRequest:(LostintravelsdkApollo_apiApolloRequest<id<LostintravelsdkApollo_apiOperationData>> *)request __attribute__((swift_name("stopOperation(request:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (LostintravelsdkOkioByteString *)toByteString:(NSDictionary<NSString *, id> *)receiver __attribute__((swift_name("toByteString(_:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (NSDictionary<NSString *, id> *)toMessageMap:(NSString *)receiver __attribute__((swift_name("toMessageMap(_:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (NSString *)toUtf8:(NSDictionary<NSString *, id> *)receiver __attribute__((swift_name("toUtf8(_:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) id<LostintravelsdkApollo_runtimeWsProtocolListener> listener __attribute__((swift_name("listener")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) id<LostintravelsdkApollo_runtimeWebSocketConnection> webSocketConnection __attribute__((swift_name("webSocketConnection")));
@end

__attribute__((swift_name("Apollo_runtimeWsProtocolListener")))
@protocol LostintravelsdkApollo_runtimeWsProtocolListener
@required
- (void)generalErrorPayload:(NSDictionary<NSString *, id> * _Nullable)payload __attribute__((swift_name("generalError(payload:)")));
- (void)networkErrorCause:(LostintravelsdkKotlinThrowable *)cause __attribute__((swift_name("networkError(cause:)")));
- (void)operationCompleteId:(NSString *)id __attribute__((swift_name("operationComplete(id:)")));
- (void)operationErrorId:(NSString *)id payload:(NSDictionary<NSString *, id> * _Nullable)payload __attribute__((swift_name("operationError(id:payload:)")));
- (void)operationResponseId:(NSString *)id payload:(NSDictionary<NSString *, id> *)payload __attribute__((swift_name("operationResponse(id:payload:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol LostintravelsdkKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<LostintravelsdkKotlinKClass>)kClass provider:(id<LostintravelsdkKotlinx_serialization_coreKSerializer> (^)(NSArray<id<LostintravelsdkKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<LostintravelsdkKotlinKClass>)kClass serializer:(id<LostintravelsdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<LostintravelsdkKotlinKClass>)baseClass actualClass:(id<LostintravelsdkKotlinKClass>)actualClass actualSerializer:(id<LostintravelsdkKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<LostintravelsdkKotlinKClass>)baseClass defaultDeserializerProvider:(id<LostintravelsdkKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)polymorphicDefaultDeserializerBaseClass:(id<LostintravelsdkKotlinKClass>)baseClass defaultDeserializerProvider:(id<LostintravelsdkKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)polymorphicDefaultSerializerBaseClass:(id<LostintravelsdkKotlinKClass>)baseClass defaultSerializerProvider:(id<LostintravelsdkKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol LostintravelsdkKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol LostintravelsdkKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol LostintravelsdkKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol LostintravelsdkKotlinKClass <LostintravelsdkKotlinKDeclarationContainer, LostintravelsdkKotlinKAnnotatedElement, LostintravelsdkKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCustomTypeValueCompanion")))
@interface LostintravelsdkApollo_apiCustomTypeValueCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkApollo_apiCustomTypeValueCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (LostintravelsdkApollo_apiCustomTypeValue<id> *)fromRawValueValue:(id _Nullable)value __attribute__((swift_name("fromRawValue(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl.Companion")))
@interface LostintravelsdkKtor_httpUrlCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_httpUrlCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Ktor_httpParameters")))
@protocol LostintravelsdkKtor_httpParameters <LostintravelsdkKtor_utilsStringValues>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol")))
@interface LostintravelsdkKtor_httpURLProtocol : LostintravelsdkBase
- (instancetype)initWithName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("init(name:defaultPort:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkKtor_httpURLProtocolCompanion *companion __attribute__((swift_name("companion")));
- (LostintravelsdkKtor_httpURLProtocol *)doCopyName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("doCopy(name:defaultPort:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod.Companion")))
@interface LostintravelsdkKtor_httpHttpMethodCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_httpHttpMethodCompanion *shared __attribute__((swift_name("shared")));
- (LostintravelsdkKtor_httpHttpMethod *)parseMethod:(NSString *)method __attribute__((swift_name("parse(method:)")));
@property (readonly) NSArray<LostintravelsdkKtor_httpHttpMethod *> *DefaultMethods __attribute__((swift_name("DefaultMethods")));
@property (readonly) LostintravelsdkKtor_httpHttpMethod *Delete __attribute__((swift_name("Delete")));
@property (readonly) LostintravelsdkKtor_httpHttpMethod *Get __attribute__((swift_name("Get")));
@property (readonly) LostintravelsdkKtor_httpHttpMethod *Head __attribute__((swift_name("Head")));
@property (readonly) LostintravelsdkKtor_httpHttpMethod *Options __attribute__((swift_name("Options")));
@property (readonly) LostintravelsdkKtor_httpHttpMethod *Patch __attribute__((swift_name("Patch")));
@property (readonly) LostintravelsdkKtor_httpHttpMethod *Post __attribute__((swift_name("Post")));
@property (readonly) LostintravelsdkKtor_httpHttpMethod *Put __attribute__((swift_name("Put")));
@end

__attribute__((swift_name("KotlinMapEntry")))
@protocol LostintravelsdkKotlinMapEntry
@required
@property (readonly) id _Nullable key __attribute__((swift_name("key")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("Ktor_httpHeaderValueWithParameters")))
@interface LostintravelsdkKtor_httpHeaderValueWithParameters : LostintravelsdkBase
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<LostintravelsdkKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkKtor_httpHeaderValueWithParametersCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)parameterName:(NSString *)name __attribute__((swift_name("parameter(name:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSArray<LostintravelsdkKtor_httpHeaderValueParam *> *parameters __attribute__((swift_name("parameters")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType")))
@interface LostintravelsdkKtor_httpContentType : LostintravelsdkKtor_httpHeaderValueWithParameters
- (instancetype)initWithContentType:(NSString *)contentType contentSubtype:(NSString *)contentSubtype parameters:(NSArray<LostintravelsdkKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(contentType:contentSubtype:parameters:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<LostintravelsdkKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) LostintravelsdkKtor_httpContentTypeCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)matchPattern:(LostintravelsdkKtor_httpContentType *)pattern __attribute__((swift_name("match(pattern:)")));
- (BOOL)matchPattern_:(NSString *)pattern __attribute__((swift_name("match(pattern_:)")));
- (LostintravelsdkKtor_httpContentType *)withParameterName:(NSString *)name value:(NSString *)value __attribute__((swift_name("withParameter(name:value:)")));
- (LostintravelsdkKtor_httpContentType *)withoutParameters __attribute__((swift_name("withoutParameters()")));
@property (readonly) NSString *contentSubtype __attribute__((swift_name("contentSubtype")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreChildHandle")))
@protocol LostintravelsdkKotlinx_coroutines_coreChildHandle <LostintravelsdkKotlinx_coroutines_coreDisposableHandle>
@required
- (BOOL)childCancelledCause:(LostintravelsdkKotlinThrowable *)cause __attribute__((swift_name("childCancelled(cause:)")));
@property (readonly) id<LostintravelsdkKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreChildJob")))
@protocol LostintravelsdkKotlinx_coroutines_coreChildJob <LostintravelsdkKotlinx_coroutines_coreJob>
@required
- (void)parentCancelledParentJob:(id<LostintravelsdkKotlinx_coroutines_coreParentJob>)parentJob __attribute__((swift_name("parentCancelled(parentJob:)")));
@end

__attribute__((swift_name("KotlinSequence")))
@protocol LostintravelsdkKotlinSequence
@required
- (id<LostintravelsdkKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause0")))
@protocol LostintravelsdkKotlinx_coroutines_coreSelectClause0
@required
- (void)registerSelectClause0Select:(id<LostintravelsdkKotlinx_coroutines_coreSelectInstance>)select block:(id<LostintravelsdkKotlinSuspendFunction0>)block __attribute__((swift_name("registerSelectClause0(select:block:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode.Companion")))
@interface LostintravelsdkKtor_httpHttpStatusCodeCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_httpHttpStatusCodeCompanion *shared __attribute__((swift_name("shared")));
- (LostintravelsdkKtor_httpHttpStatusCode *)fromValueValue:(int32_t)value __attribute__((swift_name("fromValue(value:)")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *Accepted __attribute__((swift_name("Accepted")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *BadGateway __attribute__((swift_name("BadGateway")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *BadRequest __attribute__((swift_name("BadRequest")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *Conflict __attribute__((swift_name("Conflict")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *Continue __attribute__((swift_name("Continue")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *Created __attribute__((swift_name("Created")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *ExpectationFailed __attribute__((swift_name("ExpectationFailed")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *FailedDependency __attribute__((swift_name("FailedDependency")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *Forbidden __attribute__((swift_name("Forbidden")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *Found __attribute__((swift_name("Found")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *GatewayTimeout __attribute__((swift_name("GatewayTimeout")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *Gone __attribute__((swift_name("Gone")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *InsufficientStorage __attribute__((swift_name("InsufficientStorage")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *InternalServerError __attribute__((swift_name("InternalServerError")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *LengthRequired __attribute__((swift_name("LengthRequired")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *Locked __attribute__((swift_name("Locked")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *MethodNotAllowed __attribute__((swift_name("MethodNotAllowed")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *MovedPermanently __attribute__((swift_name("MovedPermanently")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *MultiStatus __attribute__((swift_name("MultiStatus")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *MultipleChoices __attribute__((swift_name("MultipleChoices")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *NoContent __attribute__((swift_name("NoContent")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *NonAuthoritativeInformation __attribute__((swift_name("NonAuthoritativeInformation")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *NotAcceptable __attribute__((swift_name("NotAcceptable")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *NotFound __attribute__((swift_name("NotFound")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *NotImplemented __attribute__((swift_name("NotImplemented")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *NotModified __attribute__((swift_name("NotModified")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *OK __attribute__((swift_name("OK")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *PartialContent __attribute__((swift_name("PartialContent")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *PayloadTooLarge __attribute__((swift_name("PayloadTooLarge")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *PaymentRequired __attribute__((swift_name("PaymentRequired")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *PermanentRedirect __attribute__((swift_name("PermanentRedirect")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *PreconditionFailed __attribute__((swift_name("PreconditionFailed")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *Processing __attribute__((swift_name("Processing")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *ProxyAuthenticationRequired __attribute__((swift_name("ProxyAuthenticationRequired")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *RequestHeaderFieldTooLarge __attribute__((swift_name("RequestHeaderFieldTooLarge")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *RequestTimeout __attribute__((swift_name("RequestTimeout")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *RequestURITooLong __attribute__((swift_name("RequestURITooLong")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *RequestedRangeNotSatisfiable __attribute__((swift_name("RequestedRangeNotSatisfiable")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *ResetContent __attribute__((swift_name("ResetContent")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *SeeOther __attribute__((swift_name("SeeOther")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *ServiceUnavailable __attribute__((swift_name("ServiceUnavailable")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *SwitchProxy __attribute__((swift_name("SwitchProxy")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *SwitchingProtocols __attribute__((swift_name("SwitchingProtocols")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *TemporaryRedirect __attribute__((swift_name("TemporaryRedirect")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *TooManyRequests __attribute__((swift_name("TooManyRequests")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *Unauthorized __attribute__((swift_name("Unauthorized")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *UnprocessableEntity __attribute__((swift_name("UnprocessableEntity")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *UnsupportedMediaType __attribute__((swift_name("UnsupportedMediaType")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *UpgradeRequired __attribute__((swift_name("UpgradeRequired")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *UseProxy __attribute__((swift_name("UseProxy")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *VariantAlsoNegotiates __attribute__((swift_name("VariantAlsoNegotiates")));
@property (readonly) LostintravelsdkKtor_httpHttpStatusCode *VersionNotSupported __attribute__((swift_name("VersionNotSupported")));
@property (readonly) NSArray<LostintravelsdkKtor_httpHttpStatusCode *> *allStatusCodes __attribute__((swift_name("allStatusCodes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate.Companion")))
@interface LostintravelsdkKtor_utilsGMTDateCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_utilsGMTDateCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkKtor_utilsGMTDate *START __attribute__((swift_name("START")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay")))
@interface LostintravelsdkKtor_utilsWeekDay : LostintravelsdkKotlinEnum<LostintravelsdkKtor_utilsWeekDay *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) LostintravelsdkKtor_utilsWeekDayCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) LostintravelsdkKtor_utilsWeekDay *monday __attribute__((swift_name("monday")));
@property (class, readonly) LostintravelsdkKtor_utilsWeekDay *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) LostintravelsdkKtor_utilsWeekDay *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) LostintravelsdkKtor_utilsWeekDay *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) LostintravelsdkKtor_utilsWeekDay *friday __attribute__((swift_name("friday")));
@property (class, readonly) LostintravelsdkKtor_utilsWeekDay *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) LostintravelsdkKtor_utilsWeekDay *sunday __attribute__((swift_name("sunday")));
+ (LostintravelsdkKotlinArray<LostintravelsdkKtor_utilsWeekDay *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth")))
@interface LostintravelsdkKtor_utilsMonth : LostintravelsdkKotlinEnum<LostintravelsdkKtor_utilsMonth *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) LostintravelsdkKtor_utilsMonthCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) LostintravelsdkKtor_utilsMonth *january __attribute__((swift_name("january")));
@property (class, readonly) LostintravelsdkKtor_utilsMonth *february __attribute__((swift_name("february")));
@property (class, readonly) LostintravelsdkKtor_utilsMonth *march __attribute__((swift_name("march")));
@property (class, readonly) LostintravelsdkKtor_utilsMonth *april __attribute__((swift_name("april")));
@property (class, readonly) LostintravelsdkKtor_utilsMonth *may __attribute__((swift_name("may")));
@property (class, readonly) LostintravelsdkKtor_utilsMonth *june __attribute__((swift_name("june")));
@property (class, readonly) LostintravelsdkKtor_utilsMonth *july __attribute__((swift_name("july")));
@property (class, readonly) LostintravelsdkKtor_utilsMonth *august __attribute__((swift_name("august")));
@property (class, readonly) LostintravelsdkKtor_utilsMonth *september __attribute__((swift_name("september")));
@property (class, readonly) LostintravelsdkKtor_utilsMonth *october __attribute__((swift_name("october")));
@property (class, readonly) LostintravelsdkKtor_utilsMonth *november __attribute__((swift_name("november")));
@property (class, readonly) LostintravelsdkKtor_utilsMonth *december __attribute__((swift_name("december")));
+ (LostintravelsdkKotlinArray<LostintravelsdkKtor_utilsMonth *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion.Companion")))
@interface LostintravelsdkKtor_httpHttpProtocolVersionCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_httpHttpProtocolVersionCompanion *shared __attribute__((swift_name("shared")));
- (LostintravelsdkKtor_httpHttpProtocolVersion *)fromValueName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("fromValue(name:major:minor:)")));
- (LostintravelsdkKtor_httpHttpProtocolVersion *)parseValue:(id)value __attribute__((swift_name("parse(value:)")));
@property (readonly) LostintravelsdkKtor_httpHttpProtocolVersion *HTTP_1_0 __attribute__((swift_name("HTTP_1_0")));
@property (readonly) LostintravelsdkKtor_httpHttpProtocolVersion *HTTP_1_1 __attribute__((swift_name("HTTP_1_1")));
@property (readonly) LostintravelsdkKtor_httpHttpProtocolVersion *HTTP_2_0 __attribute__((swift_name("HTTP_2_0")));
@property (readonly) LostintravelsdkKtor_httpHttpProtocolVersion *QUIC __attribute__((swift_name("QUIC")));
@property (readonly) LostintravelsdkKtor_httpHttpProtocolVersion *SPDY_3 __attribute__((swift_name("SPDY_3")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioMemory")))
@interface LostintravelsdkKtor_ioMemory : LostintravelsdkBase
- (instancetype)initWithPointer:(void *)pointer size:(int64_t)size __attribute__((swift_name("init(pointer:size:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkKtor_ioMemoryCompanion *companion __attribute__((swift_name("companion")));
- (void)doCopyToDestination:(LostintravelsdkKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length destinationOffset:(int32_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset:)")));
- (void)doCopyToDestination:(LostintravelsdkKtor_ioMemory *)destination offset:(int64_t)offset length:(int64_t)length destinationOffset_:(int64_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset_:)")));
- (int8_t)loadAtIndex:(int32_t)index __attribute__((swift_name("loadAt(index:)")));
- (int8_t)loadAtIndex_:(int64_t)index __attribute__((swift_name("loadAt(index_:)")));
- (LostintravelsdkKtor_ioMemory *)sliceOffset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("slice(offset:length:)")));
- (LostintravelsdkKtor_ioMemory *)sliceOffset:(int64_t)offset length_:(int64_t)length __attribute__((swift_name("slice(offset:length_:)")));
- (void)storeAtIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("storeAt(index:value:)")));
- (void)storeAtIndex:(int64_t)index value_:(int8_t)value __attribute__((swift_name("storeAt(index:value_:)")));
@property (readonly) void *pointer __attribute__((swift_name("pointer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@property (readonly) int32_t size32 __attribute__((swift_name("size32")));
@end

__attribute__((swift_name("Ktor_ioBuffer")))
@interface LostintravelsdkKtor_ioBuffer : LostintravelsdkBase
- (instancetype)initWithMemory:(LostintravelsdkKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkKtor_ioBufferCompanion *companion __attribute__((swift_name("companion")));
- (void)commitWrittenCount:(int32_t)count __attribute__((swift_name("commitWritten(count:)")));
- (void)discardExactCount:(int32_t)count __attribute__((swift_name("discardExact(count:)")));
- (LostintravelsdkKtor_ioBuffer *)duplicate __attribute__((swift_name("duplicate()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)duplicateToCopy:(LostintravelsdkKtor_ioBuffer *)copy __attribute__((swift_name("duplicateTo(copy:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (void)reserveEndGapEndGap:(int32_t)endGap __attribute__((swift_name("reserveEndGap(endGap:)")));
- (void)reserveStartGapStartGap:(int32_t)startGap __attribute__((swift_name("reserveStartGap(startGap:)")));
- (void)reset __attribute__((swift_name("reset()")));
- (void)resetForRead __attribute__((swift_name("resetForRead()")));
- (void)resetForWrite __attribute__((swift_name("resetForWrite()")));
- (void)resetForWriteLimit:(int32_t)limit __attribute__((swift_name("resetForWrite(limit:)")));
- (void)rewindCount:(int32_t)count __attribute__((swift_name("rewind(count:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int32_t)tryPeekByte __attribute__((swift_name("tryPeekByte()")));
- (int32_t)tryReadByte __attribute__((swift_name("tryReadByte()")));
- (void)writeByteValue:(int8_t)value __attribute__((swift_name("writeByte(value:)")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@property (readonly) int32_t endGap __attribute__((swift_name("endGap")));
@property (readonly) int32_t limit __attribute__((swift_name("limit")));
@property (readonly) LostintravelsdkKtor_ioMemory *memory __attribute__((swift_name("memory")));
@property (readonly) int32_t readPosition __attribute__((swift_name("readPosition")));
@property (readonly) int32_t readRemaining __attribute__((swift_name("readRemaining")));
@property (readonly) int32_t startGap __attribute__((swift_name("startGap")));
@property (readonly) int32_t writePosition __attribute__((swift_name("writePosition")));
@property (readonly) int32_t writeRemaining __attribute__((swift_name("writeRemaining")));
@end

__attribute__((swift_name("Ktor_ioChunkBuffer")))
@interface LostintravelsdkKtor_ioChunkBuffer : LostintravelsdkKtor_ioBuffer
- (instancetype)initWithMemory:(LostintravelsdkKtor_ioMemory *)memory origin:(LostintravelsdkKtor_ioChunkBuffer * _Nullable)origin parentPool:(id<LostintravelsdkKtor_ioObjectPool> _Nullable)parentPool __attribute__((swift_name("init(memory:origin:parentPool:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMemory:(LostintravelsdkKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) LostintravelsdkKtor_ioChunkBufferCompanion *companion __attribute__((swift_name("companion")));
- (LostintravelsdkKtor_ioChunkBuffer * _Nullable)cleanNext __attribute__((swift_name("cleanNext()")));
- (LostintravelsdkKtor_ioChunkBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)releasePool:(id<LostintravelsdkKtor_ioObjectPool>)pool __attribute__((swift_name("release(pool:)")));
- (void)reset __attribute__((swift_name("reset()")));
@property (getter=next_) LostintravelsdkKtor_ioChunkBuffer * _Nullable next __attribute__((swift_name("next")));
@property (readonly) LostintravelsdkKtor_ioChunkBuffer * _Nullable origin __attribute__((swift_name("origin")));
@property (readonly) int32_t referenceCount __attribute__((swift_name("referenceCount")));
@end

__attribute__((swift_name("Ktor_ioInput")))
@interface LostintravelsdkKtor_ioInput : LostintravelsdkBase <LostintravelsdkKtor_ioCloseable>
- (instancetype)initWithHead:(LostintravelsdkKtor_ioChunkBuffer *)head remaining:(int64_t)remaining pool:(id<LostintravelsdkKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:remaining:pool:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkKtor_ioInputCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)canRead __attribute__((swift_name("canRead()")));
- (void)close __attribute__((swift_name("close_()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)closeSource __attribute__((swift_name("closeSource()")));
- (int32_t)discardN:(int32_t)n __attribute__((swift_name("discard(n:)")));
- (int64_t)discardN_:(int64_t)n __attribute__((swift_name("discard(n_:)")));
- (void)discardExactN:(int32_t)n __attribute__((swift_name("discardExact(n:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (LostintravelsdkKtor_ioChunkBuffer * _Nullable)fill __attribute__((swift_name("fill()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (int32_t)fillDestination:(LostintravelsdkKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("fill(destination:offset:length:)")));
- (BOOL)hasBytesN:(int32_t)n __attribute__((swift_name("hasBytes(n:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)markNoMoreChunksAvailable __attribute__((swift_name("markNoMoreChunksAvailable()")));
- (int64_t)peekToDestination:(LostintravelsdkKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:)")));
- (int32_t)peekToBuffer:(LostintravelsdkKtor_ioChunkBuffer *)buffer __attribute__((swift_name("peekTo(buffer:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (NSString *)readTextMin:(int32_t)min max:(int32_t)max __attribute__((swift_name("readText(min:max:)")));
- (int32_t)readTextOut:(id<LostintravelsdkKotlinAppendable>)out min:(int32_t)min max:(int32_t)max __attribute__((swift_name("readText(out:min:max:)")));
- (NSString *)readTextExactExactCharacters:(int32_t)exactCharacters __attribute__((swift_name("readTextExact(exactCharacters:)")));
- (void)readTextExactOut:(id<LostintravelsdkKotlinAppendable>)out exactCharacters:(int32_t)exactCharacters __attribute__((swift_name("readTextExact(out:exactCharacters:)")));
- (void)release_ __attribute__((swift_name("release()")));
- (int32_t)tryPeek __attribute__((swift_name("tryPeek()")));
@property (readonly) BOOL endOfInput __attribute__((swift_name("endOfInput")));
@property (readonly) id<LostintravelsdkKtor_ioObjectPool> pool __attribute__((swift_name("pool")));
@property (readonly) int64_t remaining __attribute__((swift_name("remaining")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteReadPacket")))
@interface LostintravelsdkKtor_ioByteReadPacket : LostintravelsdkKtor_ioInput
- (instancetype)initWithHead:(LostintravelsdkKtor_ioChunkBuffer *)head pool:(id<LostintravelsdkKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:pool:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithHead:(LostintravelsdkKtor_ioChunkBuffer *)head remaining:(int64_t)remaining pool:(id<LostintravelsdkKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:remaining:pool:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) LostintravelsdkKtor_ioByteReadPacketCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)closeSource __attribute__((swift_name("closeSource()")));
- (LostintravelsdkKtor_ioByteReadPacket *)doCopy __attribute__((swift_name("doCopy()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (LostintravelsdkKtor_ioChunkBuffer * _Nullable)fill __attribute__((swift_name("fill()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (int32_t)fillDestination:(LostintravelsdkKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("fill(destination:offset:length:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Ktor_ioReadSession")))
@protocol LostintravelsdkKtor_ioReadSession
@required
- (int32_t)discardN:(int32_t)n __attribute__((swift_name("discard(n:)")));
- (LostintravelsdkKtor_ioChunkBuffer * _Nullable)requestAtLeast:(int32_t)atLeast __attribute__((swift_name("request(atLeast:)")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@end

__attribute__((swift_name("KotlinSuspendFunction1")))
@protocol LostintravelsdkKotlinSuspendFunction1 <LostintravelsdkKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:completionHandler:)")));
@end

__attribute__((swift_name("KotlinAppendable")))
@protocol LostintravelsdkKotlinAppendable
@required
- (id<LostintravelsdkKotlinAppendable>)appendValue:(unichar)value __attribute__((swift_name("append(value:)")));
- (id<LostintravelsdkKotlinAppendable>)appendValue_:(id _Nullable)value __attribute__((swift_name("append(value_:)")));
- (id<LostintravelsdkKotlinAppendable>)appendValue:(id _Nullable)value startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("append(value:startIndex:endIndex:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder.Companion")))
@interface LostintravelsdkKtor_httpURLBuilderCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_httpURLBuilderCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Ktor_httpParametersBuilder")))
@protocol LostintravelsdkKtor_httpParametersBuilder <LostintravelsdkKtor_utilsStringValuesBuilder>
@required
@end

__attribute__((swift_name("KotlinKType")))
@protocol LostintravelsdkKotlinKType
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
@property (readonly) NSArray<LostintravelsdkKotlinKTypeProjection *> *arguments __attribute__((swift_name("arguments")));

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
@property (readonly) id<LostintravelsdkKotlinKClassifier> _Nullable classifier __attribute__((swift_name("classifier")));
@property (readonly) BOOL isMarkedNullable __attribute__((swift_name("isMarkedNullable")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtimeWsFrameType")))
@interface LostintravelsdkApollo_runtimeWsFrameType : LostintravelsdkKotlinEnum<LostintravelsdkApollo_runtimeWsFrameType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) LostintravelsdkApollo_runtimeWsFrameType *text __attribute__((swift_name("text")));
@property (class, readonly) LostintravelsdkApollo_runtimeWsFrameType *binary __attribute__((swift_name("binary")));
+ (LostintravelsdkKotlinArray<LostintravelsdkApollo_runtimeWsFrameType *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol.Companion")))
@interface LostintravelsdkKtor_httpURLProtocolCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_httpURLProtocolCompanion *shared __attribute__((swift_name("shared")));
- (LostintravelsdkKtor_httpURLProtocol *)createOrDefaultName:(NSString *)name __attribute__((swift_name("createOrDefault(name:)")));
@property (readonly) LostintravelsdkKtor_httpURLProtocol *HTTP __attribute__((swift_name("HTTP")));
@property (readonly) LostintravelsdkKtor_httpURLProtocol *HTTPS __attribute__((swift_name("HTTPS")));
@property (readonly) LostintravelsdkKtor_httpURLProtocol *SOCKS __attribute__((swift_name("SOCKS")));
@property (readonly) LostintravelsdkKtor_httpURLProtocol *WS __attribute__((swift_name("WS")));
@property (readonly) LostintravelsdkKtor_httpURLProtocol *WSS __attribute__((swift_name("WSS")));
@property (readonly) NSDictionary<NSString *, LostintravelsdkKtor_httpURLProtocol *> *byName __attribute__((swift_name("byName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueParam")))
@interface LostintravelsdkKtor_httpHeaderValueParam : LostintravelsdkBase
- (instancetype)initWithName:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("init(name:value:escapeValue:)"))) __attribute__((objc_designated_initializer));
- (LostintravelsdkKtor_httpHeaderValueParam *)doCopyName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("doCopy(name:value:escapeValue:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL escapeValue __attribute__((swift_name("escapeValue")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueWithParameters.Companion")))
@interface LostintravelsdkKtor_httpHeaderValueWithParametersCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_httpHeaderValueWithParametersCompanion *shared __attribute__((swift_name("shared")));
- (id _Nullable)parseValue:(NSString *)value init:(id _Nullable (^)(NSString *, NSArray<LostintravelsdkKtor_httpHeaderValueParam *> *))init __attribute__((swift_name("parse(value:init:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType.Companion")))
@interface LostintravelsdkKtor_httpContentTypeCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_httpContentTypeCompanion *shared __attribute__((swift_name("shared")));
- (LostintravelsdkKtor_httpContentType *)parseValue:(NSString *)value __attribute__((swift_name("parse(value:)")));
@property (readonly) LostintravelsdkKtor_httpContentType *Any __attribute__((swift_name("Any")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreParentJob")))
@protocol LostintravelsdkKotlinx_coroutines_coreParentJob <LostintravelsdkKotlinx_coroutines_coreJob>
@required
- (LostintravelsdkKotlinCancellationException *)getChildJobCancellationCause __attribute__((swift_name("getChildJobCancellationCause()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectInstance")))
@protocol LostintravelsdkKotlinx_coroutines_coreSelectInstance
@required
- (void)disposeOnSelectHandle:(id<LostintravelsdkKotlinx_coroutines_coreDisposableHandle>)handle __attribute__((swift_name("disposeOnSelect(handle:)")));
- (id _Nullable)performAtomicTrySelectDesc:(LostintravelsdkKotlinx_coroutines_coreAtomicDesc *)desc __attribute__((swift_name("performAtomicTrySelect(desc:)")));
- (void)resumeSelectWithExceptionException:(LostintravelsdkKotlinThrowable *)exception __attribute__((swift_name("resumeSelectWithException(exception:)")));
- (BOOL)trySelect __attribute__((swift_name("trySelect()")));
- (id _Nullable)trySelectOtherOtherOp:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp * _Nullable)otherOp __attribute__((swift_name("trySelectOther(otherOp:)")));
@property (readonly) id<LostintravelsdkKotlinContinuation> completion __attribute__((swift_name("completion")));
@property (readonly) BOOL isSelected __attribute__((swift_name("isSelected")));
@end

__attribute__((swift_name("KotlinSuspendFunction0")))
@protocol LostintravelsdkKotlinSuspendFunction0 <LostintravelsdkKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay.Companion")))
@interface LostintravelsdkKtor_utilsWeekDayCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_utilsWeekDayCompanion *shared __attribute__((swift_name("shared")));
- (LostintravelsdkKtor_utilsWeekDay *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (LostintravelsdkKtor_utilsWeekDay *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth.Companion")))
@interface LostintravelsdkKtor_utilsMonthCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_utilsMonthCompanion *shared __attribute__((swift_name("shared")));
- (LostintravelsdkKtor_utilsMonth *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (LostintravelsdkKtor_utilsMonth *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioMemory.Companion")))
@interface LostintravelsdkKtor_ioMemoryCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_ioMemoryCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkKtor_ioMemory *Empty __attribute__((swift_name("Empty")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioBuffer.Companion")))
@interface LostintravelsdkKtor_ioBufferCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_ioBufferCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkKtor_ioBuffer *Empty __attribute__((swift_name("Empty")));
@property (readonly) int32_t ReservedSize __attribute__((swift_name("ReservedSize")));
@end

__attribute__((swift_name("Ktor_ioObjectPool")))
@protocol LostintravelsdkKtor_ioObjectPool <LostintravelsdkKtor_ioCloseable>
@required
- (id)borrow __attribute__((swift_name("borrow()")));
- (void)dispose __attribute__((swift_name("dispose()")));
- (void)recycleInstance:(id)instance __attribute__((swift_name("recycle(instance:)")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioChunkBuffer.Companion")))
@interface LostintravelsdkKtor_ioChunkBufferCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_ioChunkBufferCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkKtor_ioChunkBuffer *Empty __attribute__((swift_name("Empty")));
@property (readonly) id<LostintravelsdkKtor_ioObjectPool> EmptyPool __attribute__((swift_name("EmptyPool")));
@property (readonly) id<LostintravelsdkKtor_ioObjectPool> Pool __attribute__((swift_name("Pool")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioInput.Companion")))
@interface LostintravelsdkKtor_ioInputCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_ioInputCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteReadPacket.Companion")))
@interface LostintravelsdkKtor_ioByteReadPacketCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKtor_ioByteReadPacketCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) LostintravelsdkKtor_ioByteReadPacket *Empty __attribute__((swift_name("Empty")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection")))
@interface LostintravelsdkKotlinKTypeProjection : LostintravelsdkBase
- (instancetype)initWithVariance:(LostintravelsdkKotlinKVariance * _Nullable)variance type:(id<LostintravelsdkKotlinKType> _Nullable)type __attribute__((swift_name("init(variance:type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) LostintravelsdkKotlinKTypeProjectionCompanion *companion __attribute__((swift_name("companion")));
- (LostintravelsdkKotlinKTypeProjection *)doCopyVariance:(LostintravelsdkKotlinKVariance * _Nullable)variance type:(id<LostintravelsdkKotlinKType> _Nullable)type __attribute__((swift_name("doCopy(variance:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<LostintravelsdkKotlinKType> _Nullable type __attribute__((swift_name("type")));
@property (readonly) LostintravelsdkKotlinKVariance * _Nullable variance __attribute__((swift_name("variance")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreAtomicDesc")))
@interface LostintravelsdkKotlinx_coroutines_coreAtomicDesc : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeOp:(LostintravelsdkKotlinx_coroutines_coreAtomicOp<id> *)op failure:(id _Nullable)failure __attribute__((swift_name("complete(op:failure:)")));
- (id _Nullable)prepareOp:(LostintravelsdkKotlinx_coroutines_coreAtomicOp<id> *)op __attribute__((swift_name("prepare(op:)")));
@property LostintravelsdkKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreOpDescriptor")))
@interface LostintravelsdkKotlinx_coroutines_coreOpDescriptor : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (BOOL)isEarlierThanThat:(LostintravelsdkKotlinx_coroutines_coreOpDescriptor *)that __attribute__((swift_name("isEarlierThan(that:)")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) LostintravelsdkKotlinx_coroutines_coreAtomicOp<id> * _Nullable atomicOp __attribute__((swift_name("atomicOp")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNode.PrepareOp")))
@interface LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp : LostintravelsdkKotlinx_coroutines_coreOpDescriptor
- (instancetype)initWithAffected:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)next desc:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc *)desc __attribute__((swift_name("init(affected:next:desc:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)finishPrepare __attribute__((swift_name("finishPrepare()")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *affected __attribute__((swift_name("affected")));
@property (readonly) LostintravelsdkKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@property (readonly) LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc *desc __attribute__((swift_name("desc")));
@property (readonly) LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *next __attribute__((swift_name("next")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKVariance")))
@interface LostintravelsdkKotlinKVariance : LostintravelsdkKotlinEnum<LostintravelsdkKotlinKVariance *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) LostintravelsdkKotlinKVariance *invariant __attribute__((swift_name("invariant")));
@property (class, readonly) LostintravelsdkKotlinKVariance *in __attribute__((swift_name("in")));
@property (class, readonly) LostintravelsdkKotlinKVariance *out __attribute__((swift_name("out")));
+ (LostintravelsdkKotlinArray<LostintravelsdkKotlinKVariance *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection.Companion")))
@interface LostintravelsdkKotlinKTypeProjectionCompanion : LostintravelsdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) LostintravelsdkKotlinKTypeProjectionCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (LostintravelsdkKotlinKTypeProjection *)contravariantType:(id<LostintravelsdkKotlinKType>)type __attribute__((swift_name("contravariant(type:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (LostintravelsdkKotlinKTypeProjection *)covariantType:(id<LostintravelsdkKotlinKType>)type __attribute__((swift_name("covariant(type:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (LostintravelsdkKotlinKTypeProjection *)invariantType:(id<LostintravelsdkKotlinKType>)type __attribute__((swift_name("invariant(type:)")));
@property (readonly) LostintravelsdkKotlinKTypeProjection *STAR __attribute__((swift_name("STAR")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreAtomicOp")))
@interface LostintravelsdkKotlinx_coroutines_coreAtomicOp<__contravariant T> : LostintravelsdkKotlinx_coroutines_coreOpDescriptor
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeAffected:(T _Nullable)affected failure:(id _Nullable)failure __attribute__((swift_name("complete(affected:failure:)")));
- (id _Nullable)decideDecision:(id _Nullable)decision __attribute__((swift_name("decide(decision:)")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (id _Nullable)prepareAffected:(T _Nullable)affected __attribute__((swift_name("prepare(affected:)")));
@property (readonly) LostintravelsdkKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@property (readonly) id _Nullable consensus __attribute__((swift_name("consensus")));
@property (readonly) BOOL isDecided __attribute__((swift_name("isDecided")));
@property (readonly) int64_t opSequence __attribute__((swift_name("opSequence")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNode")))
@interface LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode : LostintravelsdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)addLastNode:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)node __attribute__((swift_name("addLast(node:)")));
- (BOOL)addLastIfNode:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)node condition:(LostintravelsdkBoolean *(^)(void))condition __attribute__((swift_name("addLastIf(node:condition:)")));
- (BOOL)addLastIfPrevNode:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)node predicate:(LostintravelsdkBoolean *(^)(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *))predicate __attribute__((swift_name("addLastIfPrev(node:predicate:)")));
- (BOOL)addLastIfPrevAndIfNode:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)node predicate:(LostintravelsdkBoolean *(^)(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *))predicate condition:(LostintravelsdkBoolean *(^)(void))condition __attribute__((swift_name("addLastIfPrevAndIf(node:predicate:condition:)")));
- (BOOL)addOneIfEmptyNode:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)node __attribute__((swift_name("addOneIfEmpty(node:)")));
- (LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc<LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *> *)describeAddLastNode:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)node __attribute__((swift_name("describeAddLast(node:)")));
- (LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc<LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *> *)describeRemoveFirst __attribute__((swift_name("describeRemoveFirst()")));
- (void)helpRemove __attribute__((swift_name("helpRemove()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)nextIfRemoved __attribute__((swift_name("nextIfRemoved()")));
- (BOOL)remove __attribute__((swift_name("remove()")));
- (id _Nullable)removeFirstIfIsInstanceOfOrPeekIfPredicate:(LostintravelsdkBoolean *(^)(id _Nullable))predicate __attribute__((swift_name("removeFirstIfIsInstanceOfOrPeekIf(predicate:)")));
- (LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)removeFirstOrNull __attribute__((swift_name("removeFirstOrNull()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isRemoved __attribute__((swift_name("isRemoved")));
@property (readonly, getter=next_) id next __attribute__((swift_name("next")));
@property (readonly) LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *nextNode __attribute__((swift_name("nextNode")));
@property (readonly) LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *prevNode __attribute__((swift_name("prevNode")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNode.AbstractAtomicDesc")))
@interface LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc : LostintravelsdkKotlinx_coroutines_coreAtomicDesc
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeOp:(LostintravelsdkKotlinx_coroutines_coreAtomicOp<id> *)op failure:(id _Nullable)failure __attribute__((swift_name("complete(op:failure:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (id _Nullable)failureAffected:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)affected __attribute__((swift_name("failure(affected:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)finishOnSuccessAffected:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("finishOnSuccess(affected:next:)")));
- (void)finishPreparePrepareOp:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("finishPrepare(prepareOp:)")));
- (id _Nullable)onPreparePrepareOp:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("onPrepare(prepareOp:)")));
- (void)onRemovedAffected:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)affected __attribute__((swift_name("onRemoved(affected:)")));
- (id _Nullable)prepareOp:(LostintravelsdkKotlinx_coroutines_coreAtomicOp<id> *)op __attribute__((swift_name("prepare(op:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (BOOL)retryAffected:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(id)next __attribute__((swift_name("retry(affected:next:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)takeAffectedNodeOp:(LostintravelsdkKotlinx_coroutines_coreOpDescriptor *)op __attribute__((swift_name("takeAffectedNode(op:)")));
- (id)updatedNextAffected:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("updatedNext(affected:next:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable affectedNode __attribute__((swift_name("affectedNode")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable originalNext __attribute__((swift_name("originalNext")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc")))
@interface LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc<T> : LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc
- (instancetype)initWithQueue:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)queue node:(T)node __attribute__((swift_name("init(queue:node:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)finishOnSuccessAffected:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("finishOnSuccess(affected:next:)")));
- (void)finishPreparePrepareOp:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("finishPrepare(prepareOp:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (BOOL)retryAffected:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(id)next __attribute__((swift_name("retry(affected:next:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)takeAffectedNodeOp:(LostintravelsdkKotlinx_coroutines_coreOpDescriptor *)op __attribute__((swift_name("takeAffectedNode(op:)")));
- (id)updatedNextAffected:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("updatedNext(affected:next:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable affectedNode __attribute__((swift_name("affectedNode")));
@property (readonly) T node __attribute__((swift_name("node")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *originalNext __attribute__((swift_name("originalNext")));
@property (readonly) LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *queue __attribute__((swift_name("queue")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc")))
@interface LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc<T> : LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc
- (instancetype)initWithQueue:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)queue __attribute__((swift_name("init(queue:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (id _Nullable)failureAffected:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)affected __attribute__((swift_name("failure(affected:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)finishOnSuccessAffected:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("finishOnSuccess(affected:next:)")));
- (void)finishPreparePrepareOp:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("finishPrepare(prepareOp:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (BOOL)retryAffected:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(id)next __attribute__((swift_name("retry(affected:next:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)takeAffectedNodeOp:(LostintravelsdkKotlinx_coroutines_coreOpDescriptor *)op __attribute__((swift_name("takeAffectedNode(op:)")));
- (id)updatedNextAffected:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("updatedNext(affected:next:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable affectedNode __attribute__((swift_name("affectedNode")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable originalNext __attribute__((swift_name("originalNext")));
@property (readonly) LostintravelsdkKotlinx_coroutines_coreLockFreeLinkedListNode *queue __attribute__((swift_name("queue")));
@property (readonly) T _Nullable result __attribute__((swift_name("result")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
